#!/usr/bin/env python3
"""Extract placed utility (reinforcement objects and gadgets) from one .rec replay.
usage: extract.py <replay.rec> <MapName> > utility.json
Works on the decompressed replay dump plus the parser's position tracks. See README (Utility)."""
import sys, os, re, json, math, struct, subprocess, tempfile, collections, glob
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
BIN = os.environ.get('R6_DISSECT_TRK_BIN') or os.path.join(HERE, '..', '..', 'bin', 'r6-dissect-trk')
TOK2OP = json.load(open(os.path.join(HERE, 'tok2op.json')))
MAPS = json.load(open(os.path.join(HERE, 'maps.json')))
sys.path.insert(0, HERE); import snap
BASEFN = lambda z: (4.2 if z > 3.2 else -0.2)       # height of the floor under z (set per map in run)
REINF = (130, 0x1ca56e9a)
LAUNCH_LABEL = {'Ash': 'Breaching Round', 'Zofia': None, 'Capitao': 'Crossbow Bolt', 'Ying': 'Candela', 'Sens': 'R.O.U. Projector', 'Grim': 'Kawan Hive'}   # class-110 launched objects by owning operator
# shared (non-operator) defender gadgets, identified by entity counter + class hash (confirmed with a custom-game test round)
SHARED = {(142, 0x00003780): 'Barbed Wire', (150, 0xa2c6c135): 'Deployable Shield'}
DEFAULT_DEBRIS = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'default_debris.json')))
def shared_type(c, hb, npos, z=None, ha=0):   # z = bytes between the object's last position and its 63 73 85 FE event (None if it never has one)
    # non-operator defender gadgets. Class hashes plus how the object moved (thrown things log many positions)
    # were read off custom-game test rounds with known placements.
    if (c, hb) == (150, 0xa2c6c135): return 'Deployable Shield'
    if c == 142 and hb in (0x00003780, 0x00005db5):
        # the class code alone is not enough (tests: barbed wire showed up under both codes), so go by how the object moved:
        # placed once (1-2 positions) = barbed wire; thrown and gone within a moment (63 event right after its last position) = impact grenade;
        # nitro cells are set off by hand much later; a proximity alarm carried to a surface and set down just stays (or is destroyed much later)
        if hb == 0x00003780 and npos > 2 and z is not None and z < 2000: return None   # thrown grenade (frag/flash/smoke) that goes off at once
        if hb == 0x00003780 and npos <= 2 and z is not None and z < 200000: return None   # hard breach charge: placed once, fires soon after
        if npos <= 2: return 'Barbed Wire'
        if z is not None and z < 5000 and hb == 0x00005db5: return 'Impact Grenade'
        return 'Nitro Cell' if hb == 0x00003780 else 'Proximity Alarm'
    if (c, hb) == (150, 0x0179539a): return 'Bulletproof Camera'
    if c == 142 and (ha & 0xff) == 0x16 and npos >= 3 and z is not None and z < 5000: return 'Impact Grenade'   # thrown, explodes on contact (class code differs between builds)
    return None
def attacker_type(c, hb, npos, gap, ha=0, z=0.0, att_owner=None, single=False, tg=None):
    """Attacker gadgets, by behaviour (class hashes change with every game build).
    The low byte of hA tells how the object is carried: 0x16 thrown, 0x9a placed on a surface, 0xb2 still in hand/at spawn.
    att_owner: True/False when the owning player's side is known, None for single-player test replays."""
    if att_owner is False: return None
    if c == 142 and att_owner is not False and (ha & 0xff) == 0x16 and tg is not None and 40 <= tg <= 110 and npos >= 25 and hb != 0x3df1:      # thrown grenade: kind by time from throw to detonation
        return 'Flash Grenade' if tg < 61.5 else 'Smoke Grenade' if tg < 70.5 else 'Frag Grenade'
    if c == 142 and hb == 0x3df1: return 'Claymore'
    if hb == 0x4447: return 'Breach Charge'
    mode = ha & 0xff
    if c == 142 and hb == 0x3780 and single:       # test-build rules (one-player replay)
        if npos <= 2: return 'Hard Breach' if gap is not None and gap < 200000 else None
        if gap is not None and gap < 2000:
            if gap >= 1250: return 'Smoke Grenade'
            return 'Frag Grenade' if npos >= 60 else 'Flash Grenade'
        return None
    if att_owner and c == 142:
        if mode == 0x16 and npos >= 25 and gap is not None and gap < 20000:      # thrown grenade; flight length separates the kinds
            if gap < 2000: return 'Smoke Grenade' if gap >= 1250 else ('Frag Grenade' if npos >= 60 else 'Flash Grenade')
            return 'Flash Grenade' if npos < 60 else 'Frag Grenade' if npos < 80 else 'Smoke Grenade'
        if mode == 0x9a and npos <= 2:                                            # placed: low on the floor = claymore, up on a wall = breach charge
            elev = z - BASEFN(z)
            return 'Claymore' if elev < 0.5 else 'Breach Charge'
    # launched gadgets, each pinned to its operator by single-operator test rounds (Alpha 04)
    if c == 110 and hb == 0x5b38: return 'Breaching Round'                 # Ash
    if c == 114 and hb == 0xd30bbc16: return 'Airjab'                      # Nomad
    if c == 146 and hb == 0x20a13a16: return 'SELMA Charge'                # Ace
    if c == 162 and hb == 0x133b5100: return 'Shock Drone'                 # Twitch
    if c == 110 and hb == 0x5b52 and npos >= 25: return 'Concussion Round'   # Zofia: long arc
    if c == 110 and hb == 0x4897: return 'Withdrawal Round'                    # Zofia: instant impact
    if att_owner and c == 146 and hb in (0xadff9316, 0x161efd85) and npos >= 3: return 'Launcher Round'
    return None


def throw_groups(P, G):
    """Groups (about 1/28 s) from the moment a thrown grenade leaves the hand (speed > 10 m/s) to its last tracked position, which is the
    detonation. Measured on test rounds with known throws: flash 53-58, smoke 65-66, frag 75-78 (a cooked grenade is shorter)."""
    if len(P) < 6: return None
    g = np.searchsorted(G, [p[3] for p in P])
    for i in range(1, len(P)):
        dt = max(int(g[i] - g[i-1]), 1) / 28.0
        if math.dist(P[i][:3], P[i-1][:3]) / dt > 10: return int(g[-1] - g[i-1])
    return None

def fire_gap(raw, ref, last_o):
    pat = struct.pack('<I', ref); i = raw.find(pat); best = None
    while i != -1:
        if raw[i+12:i+16] == b'\x63\x73\x85\xfe' and i >= last_o:
            best = i - last_o if best is None else min(best, i - last_o)
        i = raw.find(pat, i+1)
    return best
def has63(raw, ref):
    pat = struct.pack('<I', ref); i = raw.find(pat)
    while i != -1:
        if raw[i+12:i+16] == b'\x63\x73\x85\xfe': return True
        i = raw.find(pat, i+1)
    return False
def _load_hatches():
    """Soft hatches per map: [{fx, fy, wx, wy, f, z}]. The blueprints draw a hatch on every floor it can be seen from, so the same hatch can sit on two floors;
    it is one hatch, standing in the floor of the highest floor it is drawn on (z = that floor's height). Border's list is the top floor only."""
    out = {}
    for key, cfg in MAPS.items():
        nm = re.sub(r'\s', '', cfg.get('name', key)).lower()
        for fn in glob.glob(os.path.join(HERE, '..', '..', 'public', 'maps', '*.json')):
            try: d = json.load(open(fn))
            except Exception: continue
            if re.sub(r'\s', '', d.get('name', '')).lower() != nm or not d.get('hatches'): continue
            order = [f[0] for f in cfg['floorSplits']] if cfg.get('floorSplits') else ['ground', 'top']
            fb = cfg.get('floorBase') or {'ground': -0.2, 'top': 4.2}
            hs = []
            for fl in sorted(d['hatches'], key=lambda f: -order.index(f) if f in order else 0):      # highest floor first
                for h in d['hatches'][fl]:
                    if any(math.hypot(h['wx'] - o['wx'], h['wy'] - o['wy']) < 1.5 for o in hs): continue
                    hs.append(dict(h, f=fl, z=fb.get(fl, 4.2)))
            out[key] = hs
    return out
HATCHES = _load_hatches()
OP_ALIAS = {'Operator(456757346397)': 'Noor'}

def spawns(b):
    out = {}
    for m in re.finditer(re.escape(bytes.fromhex('617385fe')), b):
        o = m.start()
        if o < 12 or b[o-12:o-8] != b[o+4:o+8]: continue
        ref = struct.unpack('<I', b[o-12:o-8])[0]
        if ref in out: continue
        out[ref] = dict(o=o, cnt=struct.unpack('<I', b[o-4:o])[0], hA=struct.unpack('<I', b[o+60:o+64])[0], hB=struct.unpack('<I', b[o+64:o+68])[0])
    return out

def group_starts(b):
    """Start offsets of the movement groups (chains of position records). Groups come at a steady rate (about 27.7 a second),
    so a group number works as a clock: attackers first appear when the 45 s of prep end."""
    ms = [m.start() for m in re.finditer(b'[\x60-\x63]\x73\x85\xfe', b)]
    if not ms: return np.array([], dtype=np.int64)
    st = [ms[0]]
    for p, a in zip(ms, ms[1:]):
        if p + struct.unpack('<I', b[p-4:p])[0] + 12 != a: st.append(a)
    return np.array(st, dtype=np.int64)

def positions(b, lim):
    pos = collections.defaultdict(list)
    for m in re.finditer(re.escape(bytes.fromhex('607385fe')), b):
        o = m.start()
        if o < 12 or not (b[o+4] & 0x80): continue
        x, y, z = struct.unpack('<3f', b[o+6:o+18])
        if abs(x) < 0.01 or abs(y) < 0.01 or (abs(x) < 0.1 and abs(y) < 0.1): continue   # an object that is gone/not yet placed reports (0, 0): not a position (drew gadgets at the map origin)
        if all(math.isfinite(v) for v in (x, y, z)) and lim['x'][0] < x < lim['x'][1] and lim['y'][0] < y < lim['y'][1] and lim['z'][0] < z < lim['z'][1]:
            pos[struct.unpack('<I', b[o-12:o-8])[0]].append((x, y, z, o))
    return pos

def split_teams(refs, tracks, inside):
    if len(refs) < 2: return list(refs), []   # single-player test replay
    gaps = sorted(range(len(refs)-1), key=lambda i: -(refs[i+1]-refs[i]))
    cut = gaps[0] + 1; A, B = refs[:cut], refs[cut:]
    def frac(g):
        s = c = 0
        for r in g:
            for p in tracks.get(r, [])[:40]:
                s += inside['x'][0] < p['x'] < inside['x'][1] and inside['y'][0] < p['y'] < inside['y'][1]; c += 1
        return s / max(c, 1)
    if min(len(A), len(B)) < len(refs) // 2 - 1:       # a player whose object id sits far from his team's (joined late, reconnected): the split by id gap is wrong, so sort each player by where he starts
        D = [r for r in refs if frac([r]) > 0.5]; At = [r for r in refs if r not in D]
        if D and At: return D, At
    return (A, B) if frac(A) > frac(B) else (B, A)

def destruction(raw, mapname, cfg, t0=None, PT=None, NAMES=None):
    """Walls broken in the round (head holes, rotates) and soft hatches opened. Each break spawns small debris objects
    (tag 62 73 85 FE); the ones every round already has are the map defaults and are removed. What is left is grouped into
    bursts (pieces spawn about 150 bytes apart): the first 3 pieces of a burst sit on the broken wall, so their median is the position.
    A break counts only if some player is within 20 m (explosives break walls from afar) of it at that moment (debris also streams in for walls nobody touched).
    A burst with extra pieces on the same floor within 3 m shortly after it is a rotate (tests: R04 holes had none, rotates 1-2 each)."""
    base = DEFAULT_DEBRIS.get(mapname)
    if not base: return []
    base = {tuple(k) for k in base}
    # a hatch that most sample rounds opened would count as "always there": keep the pieces on hatches out of the defaults so an opening still shows
    base = {k for k in base if not any(math.hypot(k[1] - h['wx'], k[2] - h['wy']) < 3.0 and abs(k[3] - snap.floor_base(cfg, k[3])) < 0.5 for h in HATCHES.get(mapname, []))}
    bx, by = cfg['bounds']['x'], cfg['bounds']['y']
    rs = []; _all = []
    for m in re.finditer(b'\x62\x73\x85\xfe', raw):
        o = m.start()
        if o + 28 > len(raw): continue
        sub = struct.unpack('<I', raw[o+8:o+12])[0]; x, y, z = struct.unpack('<fff', raw[o+16:o+28])
        if not (bx[0] < x < bx[1] and by[0] < y < by[1]) or not (cfg['pos']['z'][0] < z < cfg['pos']['z'][1]): continue
        if os.environ.get('R6_DBG_ALL'): _all.append((o, x, y, z, (sub, round(x, 1), round(y, 1), round(z, 1)) in base))
        if (sub, round(x, 1), round(y, 1), round(z, 1)) in base: continue
        rs.append((o, x, y, z))
    rs.sort()
    if os.environ.get('R6_DBG_ALL'): json.dump(_all, open(os.environ['R6_DBG_ALL'], 'w'))
    if os.environ.get('R6_DBG_DEBRIS'): json.dump(dict(rs=rs, t0=t0, n=len(raw)), open(os.environ['R6_DBG_DEBRIS'], 'w'))

    def nearest_player(o, x, y, z, r=20.0):
        """Reference of the player closest to the spot when it broke (None if nobody within r metres)."""
        best = (r, None)
        for ref, (to, tx) in (PT or {}).items():
            k = int(np.searchsorted(to, o))
            for j in (k-2, k-1, k, k+1):
                if 0 <= j < len(to) and abs(float(to[j]) - o) < 120000 and abs(tx[j][2]-z) < 5.0:
                    dd = math.hypot(tx[j][0]-x, tx[j][1]-y)
                    if dd < best[0]: best = (dd, ref)
        return best[1]

    def player_near(o, x, y, z, r=20.0):
        if PT is None: return True
        return nearest_player(o, x, y, z, r) is not None

    def who_of(o, x, y, z, r=20.0):
        ref = nearest_player(o, x, y, z, r) if PT else None
        nm = (NAMES or {}).get(ref)
        return (nm[0], nm[1]) if nm else (None, None)

    out = []; hs = HATCHES.get(mapname, []); lone = set()
    bid, nb = [], []                    # burst of each piece (pieces of one break spawn ~150 bytes apart) and how many pieces it has
    for r in rs:
        if bid and r[0] - rs[len(bid)-1][0] < 400: bid.append(bid[-1])
        else: bid.append(len(nb)); nb.append(0)
        nb[bid[-1]] += 1
    # opened soft hatches: a lone piece (nothing else within 5 m in the same burst) right on a hatch
    for i, r in enumerate(rs):
        near = sorted((math.hypot(r[1]-h['wx'], r[2]-h['wy']), j) for j, h in enumerate(hs) if abs(r[3] - h['z']) < 0.8 or (2.5 < r[3] - h['z'] < 5.5 and math.hypot(r[1]-h['wx'], r[2]-h['wy']) < 2.0))      # a roof hatch opens in the roof, a few metres above the top floor
        anyd = min([math.hypot(r[1]-h['wx'], r[2]-h['wy']) for h in hs] or [99])
        floorlevel = abs(r[3] - snap.floor_base(cfg, r[3])) < 0.5
        if (not near or near[0][0] >= 3.2) and not (floorlevel and anyd < 2.2): continue
        same = [j for j in range(len(rs)) if bid[j] == bid[i] and abs(rs[j][3] - r[3]) < 0.8]
        if len(same) > 2: continue      # three or more pieces together on one floor are a wall, not a hatch (pieces that fell to the floor below do not count)
        if not (near and near[0][0] < 1.5) and any(bid[j] != bid[i] and nb[bid[j]] > 2 and 0 < r[0]-rs[j][0] < 150000 and abs(rs[j][3]-r[3]) < 1.0 and math.hypot(rs[j][1]-r[1], rs[j][2]-r[2]) < 5 for j in range(len(rs))): continue      # a piece on another floor is not part of this one
        if not player_near(r[0], r[1], r[2], r[3], 12.0): continue
        lone.add(i)
        lone.update(j for j in range(len(rs)) if bid[j] == bid[i] and rs[j][3] < r[3] - 2.0 and math.hypot(rs[j][1]-r[1], rs[j][2]-r[2]) < 8.0)      # what fell through the opening onto the floor below
        wh, wop = who_of(r[0], r[1], r[2], r[3], 12.0)
        if not near or near[0][0] >= 3.2:
            # a hatch drawn on another floor lies right here: the blueprint puts it on the wrong floor, so the opening stays where the debris fell, on the floor it fell on
            if any(o.get('t') == 'hatch' and o['f'] == snap.floor_of(cfg, r[3]) and math.hypot(o['x']-r[1], o['y']-r[2]) < 2.0 for o in out): continue
            out.append(dict(k='x', t='hatch', hatch=None, op=wop, who=wh, ownerOp=wop, side=None, n=1, x=round(r[1], 2), y=round(r[2], 2), z=round(r[3], 2), f=snap.floor_of(cfg, r[3]),
                            at=round(r[0] / max(len(raw), 1), 3), prep=(r[0] < t0) if t0 else None))
            continue
        if any(o.get('hatch') == near[0][1] for o in out): continue   # same hatch already counted
        h = hs[near[0][1]]
        out.append(dict(k='x', t='hatch', hatch=near[0][1], op=wop, who=wh, ownerOp=wop, side=None, n=1, x=h['wx'], y=h['wy'], z=round(r[3], 2), f=h['f'],
                        at=round(r[0] / max(len(raw), 1), 3), prep=(r[0] < t0) if t0 else None))
    rs = [r for i, r in enumerate(rs) if i not in lone]

    bursts = []
    for r in rs:
        if bursts and r[0] - bursts[-1][-1][0] < 400: bursts[-1].append(r)
        else: bursts.append([r])
    used = set()
    for bi, bu in enumerate(bursts):
        if len(bu) < 3 or bi in used: continue        # one or two stray pieces are not a break; a burst already counted as the tail of an earlier break is the same break
        first = bu[:3]
        x = float(np.median([q[1] for q in first])); y = float(np.median([q[2] for q in first])); z = float(np.median([q[3] for q in first]))
        if not player_near(bu[0][0], x, y, z): continue
        tail = [q for bj, b2 in enumerate(bursts) if bj != bi for q in b2
                if 0 < q[0] - bu[0][0] < 150000 and abs(q[3]-z) < 0.3 and math.hypot(q[1]-x, q[2]-y) < 3.0]
        used.update(bj for bj, b2 in enumerate(bursts) if bj != bi and len(b2) >= 3 and any(q in tail for q in b2))
        wh, wop = who_of(bu[0][0], x, y, z)
        out.append(dict(k='x', t='rotate' if tail else 'hole', op=wop, who=wh, ownerOp=wop, side=None, n=len(bu) + len(tail),
                        x=round(x, 2), y=round(y, 2), z=round(z, 2), f=snap.floor_of(cfg, z), at=round(bu[0][0] / max(len(raw), 1), 3), prep=(bu[0][0] < t0) if t0 else None))
    # holes shot out piece by piece (bullets, melee: one debris piece per hit, minutes apart) never form a burst of three: three or more
    # single pieces within 1 m of each other on one floor are still one hole (Bank audit: the same wall was shot 4-5 times per round and showed nothing)
    left = [q for bu in bursts if len(bu) < 3 for q in bu]
    taken = set()
    for i, q in enumerate(left):
        if i in taken: continue
        fl = snap.floor_of(cfg, q[3])
        grp = [j for j, w in enumerate(left) if j not in taken and snap.floor_of(cfg, w[3]) == fl and math.hypot(w[1]-q[1], w[2]-q[2]) < 1.2]
        if len(grp) < 3: continue
        pcs = [left[j] for j in grp]
        x = float(np.median([w[1] for w in pcs])); y = float(np.median([w[2] for w in pcs])); z = min(w[3] for w in pcs)
        if os.environ.get('R6_DBG_CL'): print('CL', round(x,1), round(y,1), len(pcs), player_near(pcs[0][0], x, y, z), file=sys.stderr)
        if not any(player_near(w[0], x, y, z) for w in pcs): continue      # nobody close when the first piece fell can still be there for the last
        taken.update(grp)
        wh, wop = who_of(pcs[0][0], x, y, z)
        out.append(dict(k='x', t='hole', op=wop, who=wh, ownerOp=wop, side=None, n=len(pcs), x=round(x, 2), y=round(y, 2), z=round(z, 2), f=fl,
                        at=round(pcs[0][0] / max(len(raw), 1), 3), prep=(pcs[0][0] < t0) if t0 else None))
    return out

def run(rec, mapname):
    global BASEFN
    cfg = MAPS[mapname]; cfg.setdefault('name', mapname)
    BASEFN = lambda z: snap.floor_base(cfg, z)
    d = tempfile.mkdtemp()
    jp, dp = os.path.join(d, 'r.json'), os.path.join(d, 'dump.bin')
    subprocess.run([BIN, rec, '-o', jp], check=True, capture_output=True, timeout=180)
    subprocess.run([BIN, rec, '-p', '-o', dp], check=True, capture_output=True, timeout=180)
    J = json.load(open(jp)); raw = open(dp, 'rb').read()
    import shutil; shutil.rmtree(d, ignore_errors=True)      # the decompressed dump is large: do not leave it in /tmp
    sp = spawns(raw); pos = positions(raw, cfg['pos'])
    # the class number of a player object depends on the game version: 478 from Y11S3, 494 in Y11S2 (the one with ten spawns)
    PCNT = max((478, 494), key=lambda c: sum(1 for s in sp.values() if s['cnt'] == c))
    refs = sorted(r for r, s in sp.items() if s['cnt'] == PCNT)
    T = {int(t['id'], 16): t['points'] for t in J['tracks']}
    dref, aref = split_teams(refs, T, cfg['inside'])
    TO = {r: np.array([q['o'] for q in T[r]]) for r in refs if r in T}
    TX = {r: np.array([[q['x'], q['y'], q['z']] for q in T[r]]) for r in refs if r in T}
    def near(r, o, x, y):
        k = int(np.searchsorted(TO[r], o)); best = 9e9
        for j in (-2, -1, 0, 1):
            kk = min(max(k+j, 0), len(TO[r])-1); best = min(best, math.hypot(TX[r][kk][0]-x, TX[r][kk][1]-y))
        return best
    who, user = {}, {}
    for p in J['players']:
        pat = struct.pack('<Q', p['id'])
        for m in re.finditer(re.escape(pat), raw):
            o = m.start()
            if raw[o+8] != 0x39: continue
            k = 13 if raw[o+9] == 0x04 else 21 if raw[o+9] == 0x14 else None
            if k is None: continue
            r = struct.unpack('<I', raw[o+k:o+k+4])[0]
            if r in refs and raw[o+k+4:o+k+8] == b'\0\0\0\0':
                who[r] = OP_ALIAS.get(p['operator']['name'], p['operator']['name']); user[r] = p['username']; break
    bx, by = cfg['bounds']['x'], cfg['bounds']['y']
    # the k-th player spawned is the k-th entry of the replay's player list (checked on both sides of several matches)
    spawned = [r for o, r in sorted((s['o'], r) for r, s in sp.items() if s['cnt'] == PCNT)]
    if len(spawned) == len(J['players']):
        for r, p in zip(spawned, J['players']):
            who[r] = OP_ALIAS.get(p['operator']['name'], p['operator']['name']); user[r] = p['username']
    single = len(J['players']) < 2      # one-player test replay: team info comes from the round's team roles
    single_role = False
    if single and J['players']:
        tr = J['teams'][J['players'][0]['teamIndex']].get('role') if J.get('teams') else None
        single_role = (tr == 'Attack')
    # owner is known from spawn order; the old class-code table (TOK2OP) is only a fallback for the operator name
    items = []
    Gall = group_starts(raw)
    for ref, s in sp.items():
        c = s['cnt']; key = f"{c}:{s['hA']:08x}" + (f":{s['hB']:08x}" if c == 146 else '')
        P = pos.get(ref, [])
        if os.environ.get('R6_DBG_R') and (c, s['hA']) == REINF: print('REINF', '%08x' % s['hB'], s['o'], len(P), [tuple(round(v, 1) for v in p_[:3]) for p_ in P[:2]], file=sys.stderr)
        if os.environ.get('R6_DBG_B') and c == 142 and s['hA'] == 0x2d1ffa9a: print('BARB', '%08x' % s['hB'], s['o'], len(P), [tuple(round(v, 1) for v in p_[:3]) for p_ in P[:3]], file=sys.stderr)
        if not P: continue
        if (c, s['hA']) == REINF and (s['o'] > 2e6 or (s['hB'] >> 24) == 0x70): k = 'r' if (s['hB'] >> 24) == 0x70 else 'h'; pair = any(t['hA'] == 0x133b51f7 and 0 < s['o']-t['o'] < 20000 for t in sp.values())
        elif (c in (142, 146, 150, 154, 110, 162) or (c == 114 and s['hB'] in (0xd30bbc16, 0x25eb6416))) and key != '150:133b51f7' and key != '146:59f6d09a:33c17729':
            last = P[-3:]
            if len(P) > 3 and c not in (154, 110, 114, 162) and s['hB'] not in (0x5db5, 0xaa483f16, 0x2d171916, 0x57fca816) and (s['hA'] & 0xff) != 0x16 and (max(p[0] for p in last)-min(p[0] for p in last) > .3 or max(p[1] for p in last)-min(p[1] for p in last) > .3): continue
            if not (bx[0] < P[-1][0] < bx[1] and by[0] < P[-1][1] < by[1]): continue
            k = 'g'
        elif c == 114 and s['hB'] == 0xc9822016 and bx[0] < P[-1][0] < bx[1] and by[0] < P[-1][1] < by[1]:
            k = 'g'   # Mozzie pods (Pest Launcher): their own entity class, with full position tracks
        else: continue
        q = P[0] if k in ('r', 'h') else P[-1]
        if k == 'r' and os.environ.get('R6_DBG_R2'): print('R2', round(P[0][0],1), round(P[0][1],1), 'npos', len(P), 'first', round(P[0][3]/len(raw),3), 'last', round(P[-1][3]/len(raw),3), 'has63', has63(raw, ref), 'fire', fire_gap(raw, ref, P[-1][3]), file=sys.stderr)
        if k == 'h' and os.environ.get('R6_DBG_H'): print('HDBG', key, '%08x' % s['hB'], len(P), [tuple(round(v, 2) for v in p_[:3]) for p_ in P[:6]], file=sys.stderr)
        cand = dref if k in ('r', 'h') else refs
        dd = sorted((near(r, P[0][3], P[0][0], P[0][1]), r) for r in cand if r in TO)
        owner = dd[0][1] if dd and dd[0][0] < 2.0 else None
        # launched attacker objects (rounds, bolts, projectors, charges) belong to the operator that owns that launcher: the nearest
        # player is often a teammate standing beside the shooter (audit: IQ, Sledge, Twitch, Deimos came up as owners of Ash/Zofia rounds)
        fam = None
        if k == 'g' and not single:
            if c == 110: fam = tuple(LAUNCH_LABEL)
            elif c == 114 and s['hB'] == 0xd30bbc16: fam = ('Nomad',)
            elif c == 114 and s['hB'] == 0x25eb6416: fam = ('Noor',)      # Noor's Horus Lance launcher (defender), pinned by a test round of 5 shots
            elif c == 146 and s['hB'] == 0x20a13a16: fam = ('Ace',)
            elif c == 162: fam = ('Twitch',)
        if fam:
            cands = [r for r in (refs if fam == ('Noor',) else aref) if who.get(r) in fam and r in TO]
            d2 = sorted((near(r, P[0][3], P[0][0], P[0][1]), r) for r in cands)
            owner = d2[0][1] if d2 and d2[0][0] < 3.0 else None
            if owner is None: continue       # nobody on the attacking team carries a launcher for this object
        ownop = who.get(owner) if owner else None
        gap = fire_gap(raw, ref, P[-1][3]) if k == 'g' else None
        att_owner = single_role if single else ((owner in aref) if (aref and owner) else False)
        if c == 146 and s['hB'] == 0xaa483f16: att_owner = False      # Denari's connector is a defender gadget (also in one-player tests)
        sh = None if att_owner else shared_type(c, s['hB'], len(P), gap, s['hA'])
        at = ('Drone' if c == 154 else attacker_type(c, s['hB'], len(P), gap, s['hA'], P[-1][2], att_owner, single, throw_groups(P, Gall) if c == 142 else None)) if k == 'g' else None
        if fam and c == 110: at = LAUNCH_LABEL[ownop] or ('Concussion Round' if len(P) >= 25 else 'Withdrawal Round')   # Zofia: long arc = concussion
        if k == 'g' and sh == 'Barbed Wire' and ownop == 'Mute': sh = None
        if k == 'g' and sh in ('Proximity Alarm', 'Impact Grenade') and ownop == 'Mute': continue      # Mute only has his 4 jammers: anything else read near him is not his       # Mute's Signal Disruptors (audit: 3 deployed, 4 came out as barbed wire)
        if k == 'g' and at is None and c in (110, 162): continue
        if k == 'g' and at is None and att_owner is not False and not sh and c != 114 and aref and owner in aref: continue   # unrecognised attacker object: leave out
        if os.environ.get('R6_DBG_E') and k == 'g' and s['o'] < 300000: print('EARLY', key, '%08x' % s['hB'], s['o'], ownop, sh, at, [round(v, 1) for v in P[-1][:3]], file=sys.stderr)
        items.append(dict(_n=len(P), _gap=gap, k=k, pair=pair if k in ('r','h') else False, t=key, hb='%08x' % s['hB'], cnt=c, op=(sh or at or ('Mozzie' if c == 114 and s['hB'] != 0x25eb6416 else ownop or TOK2OP.get(key))), who=user.get(owner) if owner else None, ownerOp=ownop,
                          side=('Attack' if at else 'Defense' if (sh or c == 114 or owner in dref) else 'Attack' if owner else None),   # shared defender gadgets are always defender-side
                          **({'path': [[round(p[0], 1), round(p[1], 1), round(p[2], 1)] for p in P[::max(1, len(P)//40)] + [P[-1]]]} if c == 154 else {}),
                          x=round(q[0], 2), y=round(q[1], 2), z=round(q[2], 2), off=int(q[3]),
                          f=(snap.floor_of_stuck if (sh or ownop) == 'Wamai' and k == 'g' else snap.floor_of)(cfg, q[2])))
    # where each defender stands when prep ends: attackers' tracks begin at the moment they are released
    starts = [T[r][0]['o'] for r in aref if r in T and T[r]]
    if starts:
        t0 = min(starts)
        for r in dref:
            pts = [q for q in T.get(r, []) if q['o'] <= t0]
            if not pts: continue
            q = pts[-1]
            items.append(dict(k='s', t='prep end', op=who.get(r), who=user.get(r), ownerOp=who.get(r), side='Defense',
                              x=round(q['x'], 2), y=round(q['y'], 2), z=round(q['z'], 2), f=snap.floor_of(cfg, q['z'])))
    if starts:
        # every player's position once a second on the round clock. Time 0 = the action phase begins; prep is negative.
        G = group_starts(raw); ga = int(np.searchsorted(G, t0)); Rg = ga / 45.0
        if Rg > 5:
            died = {}
            for f in J.get('matchFeedback') or []:
                if f['type']['name'] == 'Kill': died[f['target']] = 180 - f['timeInSeconds']
            for r in refs:
                if r not in TO or not len(TO[r]): continue
                el = (np.searchsorted(G, TO[r]) - ga) / Rg          # seconds since the action phase began
                tmax = min(float(el[-1]), died.get(user.get(r), 1e9))
                ts, path = [], []
                for t in range(-45, int(tmax) + 1):
                    j = int(np.searchsorted(el, t, side='right')) - 1
                    if j < 0 or t - el[j] > 3: continue
                    x, y, z = TX[r][j]
                    pad = 80 if r in aref else 0      # attackers spawn outside the map: keep their run-in (up to 80 m out) so exports can show where they are
                    if bx[0] - pad < x < bx[1] + pad and by[0] - pad < y < by[1] + pad: ts.append(t); path.append([round(float(x), 1), round(float(y), 1), round(float(z), 1)])
                if path:
                    items.append(dict(k='p', t='track', op=who.get(r), who=user.get(r), ownerOp=who.get(r), side='Attack' if r in aref else 'Defense',
                                      ts=ts, path=path, **({'dt': round(float(died[user.get(r)]), 1)} if user.get(r) in died else {}),
                                      x=path[0][0], y=path[0][1], z=path[0][2], f=snap.floor_of(cfg, path[0][2])))
    items += destruction(raw, mapname, cfg, min(starts) if starts else None, {r: (TO[r], TX[r]) for r in TO}, {r: (user[r], who.get(r)) for r in user})
    if cfg.get('reinfDebris'):
        # putting up a reinforcement/barricade drops a few debris pieces right at the object (floor height): not a broken wall
        rh = [i for i in items if i.get('k') in ('r', 'h')]
        items = [i for i in items if not (i.get('k') == 'x' and i.get('prep') is not False and (any(math.hypot(i['x'] - o['x'], i['y'] - o['y']) < 1.5 and abs(i['z'] - o['z']) < 0.3 for o in rh)))]   # only prep-time debris: a break AFTER prep next to a reinforcement is that wall being opened
    if 'floors' in cfg:
        cfg['name'] = mapname; items = snap.apply(cfg, items)
    # a time on the round clock for everything that was placed or broken (seconds since the action phase began, negative in prep)
    if starts:
        Gc = group_starts(raw); gac = int(np.searchsorted(Gc, t0)); Rc = gac / 45.0
        if Rc > 5:
            for it in items:
                o = it.pop('off', None)
                if o is None and it.get('at') is not None: o = it['at'] * len(raw)
                if o is not None and it.get('k') in ('g', 'r', 'h', 'x'): it['ct'] = round((int(np.searchsorted(Gc, o)) - gac) / Rc, 1)
    for it in items: it.pop('off', None)
    # defender gadgets that came out under the owner's own name but are not that operator's gadget: Noor has no placed gadget of her own (those are
    # barbed wire), and an operator's own gadget is the biggest group of identical objects (Goyo: 4 canisters; the 2 odd ones are something else)
    OWN = {'wamai', 'jager', 'castle', 'azami', 'mira', 'bandit', 'kaid', 'tubarao', 'maestro', 'rook', 'warden', 'thunderbird', 'doc', 'clash', 'smoke', 'tachanka', 'goyo', 'vigil', 'skopos', 'caveira', 'oryx', 'mute', 'solis', 'alibi', 'mozzie', 'valkyrie', 'pulse', 'frost', 'kapkan', 'denari', 'aruni', 'fenrir', 'melusi', 'thorn', 'ela', 'lesion', 'echo'}
    NOPLACE = {'warden', 'solis', 'vigil', 'caveira', 'pulse', 'doc', 'oryx'}       # their gadget is worn or carried, never placed: anything found under their name is something else
    # Operators whose own gadget is worn/not placed (Solis, Warden...) or who never throw anything of their own (Castle, Kaid) still carry the shared secondary gadget:
    # it spawns under THEIR class hash, so it reached the output under their own name (and was dropped as "not placed") or as barbed wire.
    # Sort it by how the object behaved: thrown and gone within a moment = impact grenade; thrown and left standing (short track, never goes off) = proximity alarm;
    # carried and set off later = nitro cell; put down once = barbed wire. Their worn-gadget object (Solis 5a36) is left out.
    OWN_WORN = {('solis', '00005a36')}
    SHARED_HB = {('castle', '0000406a'), ('kaid', '00005b0c')}
    def shared_guess(i):
        thrown = (int(i['t'].split(':')[1], 16) & 0xff) == 0x16
        n, g = i.get('_n') or 0, i.get('_gap')
        if not thrown: return 'Barbed Wire' if n <= 2 else None
        if g is not None and g < 20000: return 'Impact Grenade'
        if g is None and n <= 15: return 'Proximity Alarm'
        return 'Nitro Cell'
    keep0, relab = [], collections.defaultdict(list)
    for i in items:
        if i.get('k') == 'g' and i.get('side') == 'Defense' and i.get('cnt') == 142 and i.get('op') and i.get('op') == i.get('ownerOp'):
            lo = i['op'].lower()
            if (lo, i['hb']) in OWN_WORN: continue
            if (lo in NOPLACE) or (lo, i['hb']) in SHARED_HB:
                lab = shared_guess(i)
                if lab is None: continue
                i['op'] = lab; relab[(i.get('who'), i['hb'])].append(i)
        keep0.append(i)
    for l in relab.values():      # one operator's objects of one class are one gadget: a grenade that went off at once makes the whole group impact grenades (the twin that landed and stuck is the same item)
        if any(x['op'] == 'Impact Grenade' for x in l):
            for x in l: x['op'] = 'Impact Grenade'
    items = keep0
    cand = [i for i in items if i.get('k') == 'g' and i.get('side') == 'Defense' and i.get('cnt') == 142 and i.get('op') == i.get('ownerOp') and i.get('op')]
    grp = collections.defaultdict(list)
    for i in cand: grp[(i['who'], i['hb'])].append(i)
    top = collections.defaultdict(int)
    for (w, hb), l in grp.items(): top[w] = max(top[w], len(l))
    for (w, hb), l in grp.items():
        for i in l:
            own = i['op'].lower() in OWN
            if own and i['op'] not in ('Azami', 'Wamai') and (len(l) == top[w] or len([1 for (w2, h2) in grp if w2 == w]) == 1): continue      # Azami's and Wamai's own gadgets are the other class: a 142 under their name is the second gadget
            thrown = int(i['t'].split(':')[1], 16) & 0xff == 0x16
            i['op'] = 'Impact Grenade' if thrown else 'Barbed Wire'
    # tidy-ups: the same grenade read twice at one spot, and operators that cannot carry more than a fixed number of one gadget
    CAP = {'Mozzie': 4, 'Mute': 4, 'Goyo': 4, 'Denari': 7, 'Wamai': 7}
    keep, seen_g, cnt = [], [], collections.Counter()
    for it in sorted(items, key=lambda i: i.get('ct', -999)):
        if it.get('k') == 'g' and not it.get('op') and not it.get('side') and abs(it.get('x', 0)) < 0.01 and abs(it.get('y', 0)) < 0.01: continue      # an object with no owner, no name and no position (read at the map origin): nothing to show
        if it.get('k') == 'g' and (it.get('op') or '').lower() in NOPLACE: continue
        if it.get('k') == 'g' and it.get('op') != 'Drone':
            if any(o['op'] == it['op'] and o.get('who') == it.get('who') and o['f'] == it['f'] and math.hypot(o['x'] - it['x'], o['y'] - it['y']) < 0.3 and abs(o['z'] - it['z']) < 0.3 for o in seen_g): continue
            if it['op'] in CAP:
                cnt[(it['op'], it.get('who'))] += 1
                if cnt[(it['op'], it.get('who'))] > CAP[it['op']]: continue
            seen_g.append(it)
        keep.append(it)
    items = keep
    if os.environ.get('R6_DBG_F'): print('XALL', [(i['t'], i['f'], i['x'], i['y'], i['n'], i.get('ct'), i.get('prep')) for i in items if i.get('k') == 'x'], file=sys.stderr)
    if cfg.get('reinfDebris'):      # prep-phase debris is partly gadget set-up: drop what falls right where a defender put a gadget down a moment earlier; breaks defenders make in prep (shotgun rotates, holes) stay
        gd = [g for g in items if g.get('k') == 'g' and g.get('side') == 'Defense' and g.get('op') != 'Drone' and g.get('ct') is not None]
        items = [i for i in items if not (i.get('k') == 'x' and i.get('t') != 'hatch' and i.get('ct') is not None and i['ct'] < 0
                                          and any(g['f'] == i['f'] and abs(g['ct'] - i['ct']) < 4 and math.hypot(g['x'] - i['x'], g['y'] - i['y']) < 2.0 and abs(g['z'] - i['z']) < 1.5 for g in gd))]
        items = [i for i in items if not (i.get('k') == 'x' and i.get('t') == 'hatch' and i.get('ct') is not None and i['ct'] < 0)]
    # a barricade standing on a soft hatch is a reinforced hatch: show it on the hatch itself, once per hatch
    if mapname in HATCHES:
        seenh, drop = set(), []
        for it in sorted([i for i in items if i.get('k') == 'h' and 'fx' in i], key=lambda i: i.get('ct', -99)):
            for hi, h in enumerate(HATCHES[mapname]):
                # a hatch the blueprint draws on the floor below (seen from underneath) is a hatch in the floor above it: the barricade stands one storey higher, close to the hatch
                above = it['f'] != h['f'] and 3.0 < it['z'] - h['z'] < 5.5 and math.hypot(it['x'] - h['wx'], it['y'] - h['wy']) < 2.0
                if above or (it['f'] == h['f'] and math.hypot(it['x'] - h['wx'], it['y'] - h['wy']) < 3.0 and abs(it['z'] - h['z']) < 1.0):
                    if hi in seenh: drop.append(it)
                    else:
                        seenh.add(hi); it['rh'] = True; it['rhi'] = hi
                        if not above: it['fx'], it['fy'] = h['fx'], h['fy']      # a hatch in the floor above is drawn on this floor's plan right where the barricade stands: keep its own spot
                    break
        items = [i for i in items if not any(i is d for d in drop)]
        # putting a barricade on a hatch drops a debris piece at the hatch a few seconds later: the player who just reinforced it did not open it
        rhs = [i for i in items if i.get('k') == 'h' and i.get('rh') and i.get('ct') is not None]
        items = [i for i in items if not (i.get('k') == 'x' and i.get('t') == 'hatch' and i.get('hatch') is not None and i.get('ct') is not None and i.get('who')
                 and any(b.get('rhi') == i['hatch'] and b.get('who') == i['who'] and -2 <= i['ct'] - b['ct'] <= 10 for b in rhs))]
    # T.R.I.P. connectors work in pairs (a laser between two): match each to its mate. Both ends sit on the same floor at about the same height;
    # the nearest such connector from the same owner within 12 m is the mate (an unmatched one stands alone).
    cons = [it for it in items if it.get('k') == 'g' and it.get('hb') == 'aa483f16' and 'fx' in it]
    for a in cons:
        best = None
        for b in cons:
            if b is a or b.get('who') != a.get('who') or b.get('f') != a.get('f') or abs(b['z'] - a['z']) > 0.6: continue
            d = math.hypot(a['x'] - b['x'], a['y'] - b['y'])
            if d < 12 and (best is None or d < best[0]): best = (d, b)
        a['_mate'] = best[1] if best else None
    for a in cons:
        m = a.pop('_mate', None)
        if m is not None and m.get('_mate') is None and False: pass
        if m is not None and m['x'] == a['x'] and m['y'] == a['y']: m = None
        a['mate'] = [m['fx'], m['fy']] if m is not None else None
    for it in items: it.pop('_n', None); it.pop('_gap', None)
    return items

if __name__ == '__main__':
    json.dump(run(sys.argv[1], sys.argv[2]), sys.stdout)
