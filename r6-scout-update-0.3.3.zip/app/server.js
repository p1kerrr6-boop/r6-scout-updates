const express = require('express');
const multer = require('multer');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const store = require('./lib/store');
const jobs = require('./lib/jobs');
const { summary } = require('./lib/analyze');
const pipeline = require('./lib/pipeline');

const app = express();
const PORT = process.env.PORT || 3000;

const upload = multer({
  storage: multer.diskStorage({
    destination: os.tmpdir(),
    filename: (_req, _file, cb) => cb(null, `r6up-${crypto.randomUUID()}.rec`), // never trust the client's name on disk
  }),
  limits: { fileSize: 150 * 1024 * 1024, files: 100 },
  fileFilter: (_req, file, cb) => cb(null, /\.rec$/i.test(file.originalname)),
});

app.set('trust proxy', 1);
app.disable('x-powered-by');
app.use((_req, res, next) => {
  res.set({
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'Referrer-Policy': 'no-referrer',
    'Content-Security-Policy': "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'" + (process.env.FRAME_SRC ? `; frame-src ${process.env.FRAME_SRC}` : ''),
  });
  next();
});

// Uploads: if UPLOAD_KEY is set, a matching x-upload-key header is required. Also a small per-IP rate limit.
const UPLOAD_KEY = process.env.UPLOAD_KEY || '';
function sameKey(a, b) {
  const x = Buffer.from(String(a)), y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}
const hits = new Map();
function guardUpload(req, res, next) {
  if (UPLOAD_KEY && !sameKey(req.get('x-upload-key') || '', UPLOAD_KEY)) return res.status(401).json({ error: 'Upload key required' });
  const now = Date.now(), win = 10 * 60 * 1000, max = +process.env.UPLOAD_RATE || 30;
  const arr = (hits.get(req.ip) || []).filter((t) => now - t < win);
  if (arr.length >= max) return res.status(429).json({ error: 'Too many uploads, try again later' });
  arr.push(now);
  hits.set(req.ip, arr);
  next();
}
setInterval(() => { const now = Date.now(); for (const [ip, a] of hits) if (!a.some((t) => now - t < 600000)) hits.delete(ip); }, 600000).unref();

app.use(express.static(path.join(__dirname, 'public')));

// Upload one or more round files (a match is a folder of per-round .rec files).
app.post('/api/upload', guardUpload, upload.array('files', 100), (req, res) => {
  if (!req.files || !req.files.length) return res.status(400).json({ error: 'No .rec files received' });
  // sort by name so R01..R15 get sensible fallback numbering
  const files = req.files.slice().sort((a, b) => a.originalname.localeCompare(b.originalname));
  const job = jobs.createJob(files);
  res.status(202).json({ jobId: job.id, total: job.total });
});

app.get('/api/jobs/:id', (req, res) => {
  const job = jobs.getJob(req.params.id);
  if (!job) return res.status(404).json({ error: 'Unknown job' });
  res.json(job);
});

// Batch pipeline: one replay in, its round data and map images out (the page writes them into the folder the user picked).
// Stateless: nothing from the replay is kept on the server unless ?store=1 asks for the round to be added to the app's data.
const pipeHits = new Map();
function guardPipeline(req, res, next) {
  if (UPLOAD_KEY && !sameKey(req.get('x-upload-key') || '', UPLOAD_KEY)) return res.status(401).json({ error: 'Upload key required' });
  const now = Date.now(), win = 10 * 60 * 1000, max = +process.env.PIPELINE_RATE || 600;
  const arr = (pipeHits.get(req.ip) || []).filter((t) => now - t < win);
  if (arr.length >= max) return res.status(429).json({ error: 'Too many files, try again later' });
  arr.push(now); pipeHits.set(req.ip, arr);
  next();
}
app.post('/api/pipeline/process', guardPipeline, upload.single('file'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No .rec file received' });
  try {
    const name = path.basename(String(req.body.name || req.file.originalname || 'x.rec'));
    let edits = null;
    try { if (req.body.edits) edits = JSON.parse(req.body.edits); } catch { edits = null; }
    const { round, files, mapSlug, dir, data } = await pipeline.processRec(req.file.path, name, 1, { width: Math.min(+req.body.width || 1800, 2576), images: req.body.images !== '0', timeline: String(req.body.timeline === undefined ? 'key' : req.body.timeline).slice(0, 80), edits });
    const added = req.query.store === '1' ? store.addMany([round]) : 0;
    res.json({ id: round.id, mapSlug, dir, data, map: round.map, round: round.roundNumber, summary: pipeline.summaryOf(round), added, files: files.map((f) => ({ name: f.name, b64: f.data.toString('base64') })) });
  } catch (e) {
    res.status(422).json({ error: e.message });
  } finally {
    require('fs').rm(req.file.path, { force: true }, () => {});
  }
});
app.post('/api/pipeline/gallery', guardPipeline, express.json({ limit: '5mb' }), (req, res) => {
  res.type('html').send(pipeline.galleryHtml(Array.isArray(req.body && req.body.entries) ? req.body.entries : []));
});

app.get('/api/summary', (req, res) => {
  const { team, map, site, side, result } = req.query;
  res.json(summary(store.all(), { team, map, site, side, result }));
});

app.get('/api/health', (_req, res) => res.json({ ok: true, rounds: store.count() }));

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(err.code === 'LIMIT_FILE_SIZE' ? 413 : 500).json({ error: err.message });
});

if (require.main === module) {
  app.listen(PORT, process.env.HOST || '0.0.0.0', () => console.log(`R6 Scout listening on :${PORT}`));
}
module.exports = app;
