"""Snap raw reinforcement objects onto the blueprint's reinforceable wall slots (grey rectangles).
Items get fx/fy (raw position, 0..1 of the blueprint), and for reinforcements: sx/sy (slot segment centre), a (angle),
ln/th (segment length/thickness, fraction of image width), sid/seg/cx/cy (slot id, segment index, slot centre) or become
barricades (k='h') when no wall slot is near and the object sits in a wall opening."""
import math, os, numpy as np
from scipy import ndimage as ndi
from PIL import Image
HERE = os.path.dirname(os.path.abspath(__file__))
_cache = {}
SEG = 58.0
_LIFT = False        # the 1F northern lift below was measured on Border only

def floor_of(cfg, z):
    """Floor name for a world height. cfg['floorSplits'] = [[name, lowest z], ...] (any number of floors); older maps use floorSplitZ (ground/top)."""
    sp = cfg.get('floorSplits')
    if sp:
        f = sp[0][0]
        for name, z0 in sp:
            if z >= z0: f = name
        return f
    return 'top' if z >= cfg['floorSplitZ'] else 'ground'

def floor_of_stuck(cfg, z):
    """Floor for a Mag-NET disc: thrown from a lower floor it sticks to the underside of the floor above (a metre or so below that floor's level), which is a thing on the lower floor."""
    f = floor_of(cfg, z); sp = cfg.get('floorSplits'); fb = cfg.get('floorBase')
    if sp and fb and f in fb and z < fb[f] - 0.6:
        names = [n for n, _ in sp]
        k = names.index(f)
        if k > 0: return names[k - 1]
    return f

def floor_base(cfg, z):
    """Height of the floor the point z stands on (to tell a thing on the floor from one up on a wall)."""
    fb = cfg.get('floorBase')
    return fb[floor_of(cfg, z)] if fb else (4.2 if z > 3.2 else -0.2)

def north_lift(floor, y):
    """1F: the blueprint's northern half sits a little higher than the plain scale predicts. Standing-still tests (Tellers doorframe, bathroom corner)
    were 0.5 m and 1.0 m too far down; a lift growing by 2.2 px per metre north of y = -83 fixes both and leaves the rest of the floor untouched."""
    return 2.2 * (y + 83.0) if _LIFT and floor == 'ground' and y > -83.0 else 0.0

NORM_W = 2576
def _img(fl):
    """Blueprint as RGB, brought to the working width (2576 px) with nearest-neighbour so no new grey levels appear. All pixel constants in this file
    (slot sizes, doorway widths, snap radii) were tuned at that width; calibrations are stored in these working pixels."""
    rgb = Image.open(os.path.join(HERE, '..', '..', 'public', fl['image'].lstrip('/')))
    if rgb.mode == 'RGBA':                      # transparent blueprints: composite on white
        bg = Image.new('RGB', rgb.size, (255, 255, 255)); bg.paste(rgb, mask=rgb.split()[3]); rgb = bg
    rgb = rgb.convert('RGB')
    if rgb.width != NORM_W: rgb = rgb.resize((NORM_W, round(rgb.height * NORM_W / rgb.width)), Image.NEAREST)
    return rgb

def _load(cfg, floor):
    key = (cfg['name'], floor)
    if key in _cache: return _cache[key]
    fl = cfg['floors'][floor]
    rgb = _img(fl); a = np.array(rgb).astype(int); g = np.array(rgb.convert('L')).astype(int)
    lo, hi = fl['slotGrey']
    # slot colour: grey window by default, 'yellow' for blueprints that mark reinforceable walls in yellow
    raw = ((a[:, :, 0] > 220) & (a[:, :, 1] > 190) & (a[:, :, 2] < 120)) if fl.get('slotMode') == 'yellow' else ((g >= lo) & (g <= hi))
    so = fl.get('slotOpen', 3)
    m = ndi.binary_opening(raw, structure=np.ones((so, so)))
    lab, n = ndi.label(m, structure=np.ones((3, 3))); slots = []
    minL, maxT, ratio, minPx = fl.get('slotMinL', 35), fl.get('slotMaxT', 30), fl.get('slotRatio', 3), fl.get('slotMinPx', 150)
    for i in range(1, n+1):
        ys, xs = np.nonzero(lab == i)
        if len(xs) < minPx: continue
        c = np.array([xs.mean(), ys.mean()]); X = np.stack([xs, ys], 1) - c
        w, v = np.linalg.eigh(np.cov(X.T)); d = v[:, 1]; t = X @ d; s = X @ v[:, 0]
        L = t.max()-t.min(); T = s.max()-s.min()
        if L/max(T, 1) < ratio or T > maxT or L < minL: continue
        if any(abs(c[0]/g.shape[1]-fx) < .01 and abs(c[1]/g.shape[0]-fy) < .01 for fx, fy in fl.get('fakeSlots', [])): continue   # drawn on the blueprint but not a real wall
        slots.append(dict(c=c, d=d, t0=float(t.min()), t1=float(t.max()), L=float(L), T=float(T)))
    # the 3x3 opening above eats ragged ends of a slot (JPEG noise on the grey fill): measure each slot's length again on the unopened mask, only inside its own band
    hh, ww = raw.shape
    for sl_ in slots:
        d = sl_['d']; n_ = np.array([-d[1], d[0]]); c = sl_['c']; half = sl_['L'] / 2 + 14
        x0, x1 = int(max(0, c[0] - half)), int(min(ww, c[0] + half + 1)); y0, y1 = int(max(0, c[1] - half)), int(min(hh, c[1] + half + 1))
        ys, xs = np.nonzero(raw[y0:y1, x0:x1]); xs = xs + x0; ys = ys + y0
        rel = np.stack([xs - c[0], ys - c[1]], 1); tt = rel @ d; ss = rel @ n_
        band = (abs(ss) <= sl_['T'] / 2 + 1.5) & (tt >= sl_['t0'] - 14) & (tt <= sl_['t1'] + 14)
        if band.sum() < 20: continue
        bx, by, bt = xs[band], ys[band], tt[band]
        sub = np.zeros((y1 - y0, x1 - x0), bool); sub[by - y0, bx - x0] = True
        lab2, _ = ndi.label(sub, structure=np.ones((3, 3)))
        k = np.argmin(abs(bt)); l0 = lab2[by[k] - y0, bx[k] - x0]
        if l0 == 0: continue
        sel = lab2[by - y0, bx - x0] == l0; t_ = bt[sel]
        n0, n1 = float(t_.min()), float(t_.max())
        if n1 - n0 > sl_['L'] and n1 - n0 < sl_['L'] + 24:
            sl_['c'] = c + d * ((n0 + n1) / 2); sl_['t0'], sl_['t1'], sl_['L'] = -(n1 - n0) / 2, (n1 - n0) / 2, n1 - n0
    if fl.get('stairFilter'):                   # stair stripes are parallel pieces stacked side by side; wall slots sit end to end
        keep = []
        for i, o in enumerate(slots):
            n_ = np.array([-o['d'][1], o['d'][0]]); nb = 0
            for j, p in enumerate(slots):
                if j == i or abs(o['d'] @ p['d']) < .95: continue
                r = p['c'] - o['c']
                if 5 < abs(r @ n_) < 42 and abs(r @ o['d']) < 0.7 * max(o['L'], p['L']): nb += 1
            if nb < 2: keep.append(o)
        slots = keep
    for x0, y0, x1, y1, *tt in fl.get('extraSlots', []):       # reinforceable walls the blueprint does not draw a slot on: segments given as fractions of the image
        a_ = np.array([x0 * g.shape[1], y0 * g.shape[0]]); b_ = np.array([x1 * g.shape[1], y1 * g.shape[0]]); L_ = float(np.hypot(*(b_ - a_)))
        slots.append(dict(c=(a_ + b_) / 2, d=(b_ - a_) / L_, t0=-L_ / 2, t1=L_ / 2, L=L_, T=float(tt[0]) if tt else 14.0, extra=True))
    wall = ndi.binary_opening(g < 80, structure=np.ones((3, 3)))
    dtw = ndi.distance_transform_edt(~wall)
    _cache[key] = (slots, dtw, g.shape[1], g.shape[0])
    return _cache[key]

def _snap(slots, px, py, maxd):
    best = None
    for si, s in enumerate(slots):
        p = np.array([px, py]) - s['c']; n = max(1, round(s['L']/SEG)); seg = s['L']/n
        along = float(p @ s['d'])
        k = int(np.clip(np.floor((along-s['t0'])/seg), 0, n-1)); t = s['t0']+seg*(k+.5)
        tc = float(np.clip(along, s['t0'], s['t1'])); dist = float(np.hypot(*(s['c']+tc*s['d']-[px, py])))
        if best is None or dist < best[0]: best = (dist, s['c']+t*s['d'], s, k, si, seg)
    return best if best and best[0] <= maxd else None

def _snap_free(slots, px, py, maxd, banned):
    """Like _snap, but only wall pieces (slot, segment) that are not in `banned` (the ones reinforced this round) can be chosen."""
    best = None
    for si, s in enumerate(slots):
        p = np.array([px, py]) - s['c']; n = max(1, round(s['L']/SEG)); seg = s['L']/n
        for k in range(n):
            if (si, k) in banned: continue
            a0 = s['t0'] + seg*k; a1 = a0 + seg
            along = float(p @ s['d']); tc = float(np.clip(along, a0, a1))
            dist = float(np.hypot(*(s['c']+tc*s['d']-[px, py])))
            if best is None or dist < best[0]: best = (dist, s['c']+(a0+seg/2)*s['d'], s, k, si, seg)
    return best if best and best[0] <= maxd else None

_widx = {}
def _wallidx(cfg, floor):
    key = (cfg['name'], floor)
    if key not in _widx:
        fl = cfg['floors'][floor]
        g = np.array(_img(fl).convert('L')).astype(int)
        wall = ndi.binary_opening(g < 80, structure=np.ones((3, 3)))
        _widx[key] = ndi.distance_transform_edt(~wall, return_indices=True)
    return _widx[key]

def fit_gap(cfg, floor, px, py):
    """A barricade fills a doorway or window. Walls here run along the two axes, so for each axis look along lines near the object for an opening
    in the wall: clear between two solid wall ends 28-190 px apart (about 0.7-4.5 m). Returns (centre x, centre y, angle 0 or 90, length px) or None."""
    slots, dtw, W, H = _load(cfg, floor)
    wall = dtw == 0
    if not (0 <= int(px) < W and 0 <= int(py) < H): return None
    def solid(x, y, d, n, run=14):
        """is there a wall end at (x, y): wall under the line itself for `run` px further on, with the wall's thickness across it."""
        for t in range(0, run):
            xx = int(round(x + d[0]*t)); yy = int(round(y + d[1]*t))
            if not (0 <= xx < W and 0 <= yy < H) or not wall[yy, xx]: return False
        cnt = 0
        for o in range(-5, 6):
            xx = int(round(x + n[0]*o)); yy = int(round(y + n[1]*o))
            if 0 <= xx < W and 0 <= yy < H and wall[yy, xx]: cnt += 1
        return cnt >= 6
    best = None
    for ang, d in ((0, (1.0, 0.0)), (90, (0.0, 1.0))):
        n = (-d[1], d[0])
        for o in range(-80, 81, 2):
            x0 = px + n[0]*o; y0 = py + n[1]*o
            if not (0 <= int(x0) < W and 0 <= int(y0) < H) or wall[int(y0), int(x0)]: continue
            ends = []
            for sign in (1, -1):
                hit = None
                for t in range(1, 191):
                    xx = x0 + sign*d[0]*t; yy = y0 + sign*d[1]*t
                    if not (0 <= int(xx) < W and 0 <= int(yy) < H): break
                    if wall[int(round(yy)), int(round(xx))]: hit = t; break
                ends.append(hit)
            if None in ends or not (28 <= sum(ends) <= 190): continue
            e1 = (x0 + d[0]*ends[0], y0 + d[1]*ends[0]); e2 = (x0 - d[0]*ends[1], y0 - d[1]*ends[1])
            if not (solid(e1[0], e1[1], d, n) and solid(e2[0], e2[1], (-d[0], -d[1]), n)): continue
            # the opening must be clear along its whole length (no wall crossing the line)
            score = abs(o) + 0.2*abs(sum(ends) - 80)
            if best is None or score < best[0]:
                cx = x0 + d[0]*(ends[0]-ends[1])/2.0; cy = y0 + d[1]*(ends[0]-ends[1])/2.0
                best = (score, cx, cy, ang, float(sum(ends)))
    if best is None:
        # second pass: the object often sits on a wall end or just past the opening, so the start point may itself be wall.
        # Slide the start along each axis too, and take the opening closest to the object.
        for ang, d in ((0, (1.0, 0.0)), (90, (0.0, 1.0))):
            n = (-d[1], d[0])
            for o in range(-80, 81, 4):
                for sh in range(-120, 121, 6):
                    x0 = px + n[0]*o + d[0]*sh; y0 = py + n[1]*o + d[1]*sh
                    if not (0 <= int(x0) < W and 0 <= int(y0) < H) or wall[int(y0), int(x0)]: continue
                    ends = []
                    for sign in (1, -1):
                        hit = None
                        for t in range(1, 191):
                            xx = x0 + sign*d[0]*t; yy = y0 + sign*d[1]*t
                            if not (0 <= int(xx) < W and 0 <= int(yy) < H): break
                            if wall[int(round(yy)), int(round(xx))]: hit = t; break
                        ends.append(hit)
                    if None in ends or not (28 <= sum(ends) <= 190): continue
                    e1 = (x0 + d[0]*ends[0], y0 + d[1]*ends[0]); e2 = (x0 - d[0]*ends[1], y0 - d[1]*ends[1])
                    if not (solid(e1[0], e1[1], d, n) and solid(e2[0], e2[1], (-d[0], -d[1]), n)): continue
                    cx = x0 + d[0]*(ends[0]-ends[1])/2.0; cy = y0 + d[1]*(ends[0]-ends[1])/2.0
                    score = math.hypot(cx - px, cy - py) + 0.2*abs(sum(ends) - 80)
                    if best is None or score < best[0]: best = (score, cx, cy, ang, float(sum(ends)))
    if best is None: return None
    return best[1], best[2], best[3], best[4]

def fit_gap2(cfg, floor, px, py):
    """Fallback for barricades the strict search above cannot place: doorways in diagonal walls (45 and 135 degrees as well as the two axes) and
    openings whose wall ends are short blocks (the double-line walls draw only their end caps dark). Takes the opening closest to the object."""
    slots, dtw, W, H = _load(cfg, floor)
    wall = dtw == 0
    def at(x, y): return 0 <= int(round(x)) < W and 0 <= int(round(y)) < H and wall[int(round(y)), int(round(x))]
    def solid(x, y, d, n, run=4):        # loose on purpose: diagonal wall ends only touch the opening's line at their tip
        for t in range(0, run):
            if not at(x + d[0]*t, y + d[1]*t): return False
        return sum(1 for o in range(-5, 6) if at(x + n[0]*o, y + n[1]*o)) >= 3
    best = None
    r2 = math.sqrt(0.5)
    for ang, d in ((0, (1.0, 0.0)), (90, (0.0, 1.0)), (45, (r2, r2)), (135, (-r2, r2))):
        n = (-d[1], d[0])
        for o in range(-80, 81, 2):
            for sh in range(-120, 121, 3):
                x0 = px + n[0]*o + d[0]*sh; y0 = py + n[1]*o + d[1]*sh
                if not (0 <= int(x0) < W and 0 <= int(y0) < H) or wall[int(y0), int(x0)]: continue
                ends = []
                for sign in (1, -1):
                    hit = None
                    for t in range(1, 191):
                        if at(x0 + sign*d[0]*t, y0 + sign*d[1]*t): hit = t; break
                    ends.append(hit)
                if None in ends or not (28 <= sum(ends) <= 190): continue
                e1 = (x0 + d[0]*ends[0], y0 + d[1]*ends[0]); e2 = (x0 - d[0]*ends[1], y0 - d[1]*ends[1])
                if not (solid(e1[0], e1[1], d, n) and solid(e2[0], e2[1], (-d[0], -d[1]), n)): continue
                cx = x0 + d[0]*(ends[0]-ends[1])/2.0; cy = y0 + d[1]*(ends[0]-ends[1])/2.0
                score = math.hypot(cx - px, cy - py) + 1.0*abs(sum(ends) - 90)
                if best is None or score < best[0]: best = (score, cx, cy, ang, float(sum(ends)))
    return None if best is None else best[1:]

def fixed_fill(cfg, floor):
    slots, _, W, H = _load(cfg, floor); out = []
    for s in slots:
        n = max(1, round(s['L']/SEG)); seg = s['L']/n
        for k in range(n):
            q = s['c']+(s['t0']+seg*(k+.5))*s['d']
            out.append(dict(sx=round(q[0]/W, 4), sy=round(q[1]/H, 4), a=round(math.degrees(math.atan2(s['d'][1], s['d'][0])) % 180, 1), ln=round((seg-4)/W, 4), th=round(s['T']/W, 4)))
    return out


_hulls = {}
def _hull(cfg, floor):
    """Outline (convex hull, pixels) of the drawn building: the big wall pieces, without the title in the corner."""
    key = (cfg['name'], floor)
    if key not in _hulls:
        from scipy.spatial import ConvexHull
        fl = cfg['floors'][floor]
        g = np.array(_img(fl).convert('L')).astype(int); H, W = g.shape
        wall = ndi.binary_opening(g < 80, structure=np.ones((3, 3)))
        lab, n = ndi.label(wall, structure=np.ones((3, 3)))
        objs = ndi.find_objects(lab); area = ndi.sum(wall, lab, range(1, n+1))
        keep = [i+1 for i, sl in enumerate(objs) if area[i] > 1500 and not (sl[0].stop < 0.16*H and sl[1].stop < 0.28*W)]
        ys, xs = np.where(np.isin(lab, keep))
        pts = np.stack([xs, ys], 1)[::7]
        try: _hulls[key] = pts[ConvexHull(pts).vertices].astype(float) if len(pts) > 20 else None
        except Exception: _hulls[key] = None
    return _hulls[key]

def pull_inside(hull, px, py, maxd=60.0, margin=40.0):
    """A defender's gadget a little outside the drawn building is a calibration error at the edge, not a gadget in the street: move it just inside."""
    if hull is None: return px, py
    best = None; inside = True
    n = len(hull)
    for i in range(n):
        a = hull[i]; b = hull[(i+1) % n]; e = b - a; L = math.hypot(*e)
        if L == 0: continue
        nx, ny = e[1]/L, -e[0]/L                 # outward normal for a counter-clockwise hull
        d = (px - a[0])*nx + (py - a[1])*ny      # > 0: outside this edge
        if d > 0:
            inside = False
            if best is None or d < best[0]: best = (d, nx, ny)
    if inside or best is None: return px, py
    d, nx, ny = best
    if d > maxd: return px, py
    return px - nx*(d + margin), py - ny*(d + margin)

def apply(cfg, items):
    global _LIFT
    _LIFT = cfg.get('name') == 'Border'
    taken = {}
    # reinforcements first: a break is then never drawn on top of a wall piece that stood reinforced when the debris fell if the piece next to it is plain
    for it in sorted(items, key=lambda i: i.get('k') != 'r'):
        if it.get('path'):      # drone flight: each point on the floor it was flown on
            pf = []
            for x, y, z in it['path']:
                f = floor_of(cfg, z); fl = cfg['floors'].get(f)
                if not fl:
                    if it['k'] == 'p': pf.append(None)
                    continue
                _, _, W, H = _load(cfg, f); px = fl['sx']*x+fl['tx']; py = fl['ty']-fl['sy']*y-north_lift(f, y)
                if 0 <= px < W and 0 <= py < H: pf.append([round(px/W, 4), round(py/H, 4), f])
                elif it['k'] == 'p': pf.append([round(px/W, 4), round(py/H, 4), 'out'])     # off the blueprint (attackers still running in); one entry per second so the times stay aligned
            it['pf'] = pf
            if it['k'] == 'p': del it['path']; it['f'] = floor_of(cfg, it['z']); continue
        fl = cfg['floors'].get(it['f'])
        if not fl: it['out'] = True; continue      # a floor with no calibration yet (no reinforcements seen on it): nothing can be placed there
        slots, dtw, W, H = _load(cfg, it['f'])
        px = fl['sx']*it['x']+fl['tx']; py = fl['ty']-fl['sy']*it['y']-north_lift(it['f'], it['y'])
        if not (0 <= px < W and 0 <= py < H): it['out'] = True; continue
        if it['k'] == 'g' and it.get('side') == 'Defense' and it.get('op') != 'Drone':
            px, py = pull_inside(_hull(cfg, it['f']), px, py)
        it['fx'] = round(px/W, 4); it['fy'] = round(py/H, 4)
        if it['k'] == 'x' and it.get('t') in ('hole', 'rotate'):
            # the debris lands up to ~1.5 m off the wall it came from: pull the marker onto the nearest wall (reinforceable slot first, then any wall line)
            sn = _snap(slots, px, py, 80)
            if sn:       # the debris of a plain wall lands beside a reinforced one: put the break on the plain piece, not on the bar
                held = {(o['sid'], o['seg']) for o in items if o.get('k') == 'r' and o.get('f') == it['f'] and o.get('sid') is not None}
                if (sn[4], sn[3]) in held:
                    alt = _snap_free(slots, px, py, 80, held)
                    if alt: sn = alt
            if not sn and it.get('t') in ('hole', 'rotate') and slots:
                _, idx0 = _wallidx(cfg, it['f'])
                wy0, wx0 = idx0[:, int(py), int(px)]
                if math.hypot(wx0-px, wy0-py) > 50:
                    it['out'] = True; continue      # nothing destructible nearby (mid-room, no wall within ~1.6 m): that was loose debris (furniture), not a broken wall
            if sn: qx, qy = float(sn[1][0]), float(sn[1][1])
            else:
                _, idx = _wallidx(cfg, it['f'])
                wy, wx = idx[:, int(py), int(px)]
                qx, qy = (float(wx), float(wy)) if math.hypot(wx-px, wy-py) < 80 else (px, py)
            it['fx'] = round(qx/W, 4); it['fy'] = round(qy/H, 4)
            continue
        if it['k'] == 'h':
            gp = fit_gap(cfg, it['f'], px, py)
            if not gp or math.hypot(gp[0]-px, gp[1]-py) >= 110: gp = fit_gap2(cfg, it['f'], px, py)
            if gp and math.hypot(gp[0]-px, gp[1]-py) < 110:
                it['fx'] = round(gp[0]/W, 4); it['fy'] = round(gp[1]/H, 4); it['ba'] = round(gp[2], 1); it['bl'] = round((gp[3]-6)/W, 4)
            elif dtw[int(py), int(px)] > 120: it['out'] = True       # no doorway and more than about 4 m from any wall: a barricade cannot stand there, so it is not drawn
            continue
        if it['k'] != 'r': continue
        pin = next((q for q in fl.get('pins', []) if math.hypot(it['x'] - q[0], it['y'] - q[1]) < 1.5), None)     # world position known to belong to a given drawn slot (fraction of the image)
        sn = _snap(slots, pin[2] * W, pin[3] * H, 60) if pin else _snap(slots, px, py, 60)
        if not sn and not pin and dtw[int(py), int(px)] > 22: sn = _snap(slots, px, py, 170)
        if not sn: it['k'] = 'h'; continue
        dist, q, s, k, si, seg = sn
        used = taken.setdefault(it['f'], set())      # a wall piece holds one reinforcement: a second one read on the same piece belongs to the next free piece beside it
        if (si, k) in used:
            alt = _snap_free(slots, px, py, 90, used)
            if alt: dist, q, s, k, si, seg = alt
        used.add((si, k))
        it.update(sx=round(q[0]/W, 4), sy=round(q[1]/H, 4), a=round(math.degrees(math.atan2(s['d'][1], s['d'][0])) % 180, 1),
                  ln=round((seg-4)/W, 4), sl=round((s['L']-4)/W, 4), th=round(s['T']/W, 4), sid=si, seg=k, cx=round(float(s['c'][0])/W, 4), cy=round(float(s['c'][1])/H, 4))
    return [i for i in items if not i.get('out')]
