const express = require('express');
const multer = require('multer');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const store = require('./lib/store');
const jobs = require('./lib/jobs');
const { summary } = require('./lib/analyze');
const pipeline = require('./lib/pipeline');

const app = express();
const PORT = process.env.PORT || 3000;

const upload = multer({
  storage: multer.diskStorage({
    destination: os.tmpdir(),
    filename: (_req, _file, cb) => cb(null, `r6up-${crypto.randomUUID()}.rec`), // never trust the client's name on disk
  }),
  limits: { fileSize: 150 * 1024 * 1024, files: 100 },
  fileFilter: (_req, file, cb) => cb(null, /\.rec$/i.test(file.originalname)),
});

app.set('trust proxy', 1);
app.disable('x-powered-by');
app.use((_req, res, next) => {
  res.set({
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'Referrer-Policy': 'no-referrer',
    'Content-Security-Policy': "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'" + (process.env.FRAME_SRC ? `; frame-src ${process.env.FRAME_SRC}` : ''),
  });
  next();
});

// Uploads: if UPLOAD_KEY is set, a matching x-upload-key header is required. Also a small per-IP rate limit.
const UPLOAD_KEY = process.env.UPLOAD_KEY || '';
function sameKey(a, b) {
  const x = Buffer.from(String(a)), y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}
const hits = new Map();
function guardUpload(req, res, next) {
  if (UPLOAD_KEY && !sameKey(req.get('x-upload-key') || '', UPLOAD_KEY)) return res.status(401).json({ error: 'Upload key required' });
  const now = Date.now(), win = 10 * 60 * 1000, max = +process.env.UPLOAD_RATE || 30;
  const arr = (hits.get(req.ip) || []).filter((t) => now - t < win);
  if (arr.length >= max) return res.status(429).json({ error: 'Too many uploads, try again later' });
  arr.push(now);
  hits.set(req.ip, arr);
  next();
}
setInterval(() => { const now = Date.now(); for (const [ip, a] of hits) if (!a.some((t) => now - t < 600000)) hits.delete(ip); }, 600000).unref();

app.use(express.static(path.join(__dirname, 'public')));

// Upload one or more round files (a match is a folder of per-round .rec files).
app.post('/api/upload', guardUpload, upload.array('files', 100), (req, res) => {
  if (!req.files || !req.files.length) return res.status(400).json({ error: 'No .rec files received' });
  // sort by name so R01..R15 get sensible fallback numbering
  const files = req.files.slice().sort((a, b) => a.originalname.localeCompare(b.originalname));
  const job = jobs.createJob(files);
  res.status(202).json({ jobId: job.id, total: job.total });
});

app.get('/api/jobs/:id', (req, res) => {
  const job = jobs.getJob(req.params.id);
  if (!job) return res.status(404).json({ error: 'Unknown job' });
  res.json(job);
});

// Batch pipeline: one replay in, its round data and map images out (the page writes them into the folder the user picked).
// Stateless: nothing from the replay is kept on the server unless ?store=1 asks for the round to be added to the app's data.
const pipeHits = new Map();
function guardPipeline(req, res, next) {
  if (UPLOAD_KEY && !sameKey(req.get('x-upload-key') || '', UPLOAD_KEY)) return res.status(401).json({ error: 'Upload key required' });
  const now = Date.now(), win = 10 * 60 * 1000, max = +process.env.PIPELINE_RATE || 600;
  const arr = (pipeHits.get(req.ip) || []).filter((t) => now - t < win);
  if (arr.length >= max) return res.status(429).json({ error: 'Too many files, try again later' });
  arr.push(now); pipeHits.set(req.ip, arr);
  next();
}
app.post('/api/pipeline/process', guardPipeline, upload.single('file'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No .rec file received' });
  try {
    const name = path.basename(String(req.body.name || req.file.originalname || 'x.rec'));
    let edits = null;
    try { if (req.body.edits) edits = JSON.parse(req.body.edits); } catch { edits = null; }
    const { round, files, mapSlug, dir, data } = await pipeline.processRec(req.file.path, name, 1, { width: Math.min(+req.body.width || 1800, 2576), images: req.body.images !== '0', plain: req.body.plain === '1', droneImages: req.body.droneImages !== '0', timeline: String(req.body.timeline === undefined ? 'key' : req.body.timeline).slice(0, 80), edits });
    const added = req.query.store === '1' ? store.addMany([round]) : 0;
    res.json({ id: round.id, mapSlug, dir, data, map: round.map, round: round.roundNumber, summary: pipeline.summaryOf(round), added, files: files.map((f) => ({ name: f.name, b64: f.data.toString('base64') })) });
  } catch (e) {
    res.status(422).json({ error: e.message });
  } finally {
    require('fs').rm(req.file.path, { force: true }, () => {});
  }
});
app.post('/api/pipeline/gallery', guardPipeline, express.json({ limit: '5mb' }), (req, res) => {
  res.type('html').send(pipeline.galleryHtml(Array.isArray(req.body && req.body.entries) ? req.body.entries : []));
});

// a team's map pool from the R6 Prep server that runs next to this app in the desktop version (the same Liquipedia numbers Prep shows); kept for 30 minutes, never blocks a deck
const poolCache = new Map();
// Team names: the replays say "Geekay", Liquipedia says "Geekay Esports" (or "Team Falcons" vs "Falcons"). Ask Prep for the names Liquipedia knows and pick the closest one, so a different spelling still finds the team.
const teamKey = (n) => String(n || '').normalize('NFKD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/\b(team|esports?|gaming|club|clan)\b/g, '').replace(/[^a-z0-9]/g, '');
let lpTeams = { at: 0, names: [] };
async function lpTeamNames(base) {
  if (lpTeams.names.length && Date.now() - lpTeams.at < 60 * 60 * 1000) return lpTeams.names;
  for (let n = 0; n < 24; n++) {                                            // Prep builds its team list in the background on first use: wait for it (about 2 min at most)
    try {
      const r = await fetch(`${base}/api/meta/teams`, { signal: AbortSignal.timeout(20000) });
      const j = r.ok ? await r.json() : null;
      const names = j && Array.isArray(j.allTeams) ? j.allTeams.filter((x) => typeof x === 'string') : [];
      if (names.length && (!j.loading || n >= 6)) { lpTeams = { at: Date.now(), names }; return names; }
    } catch { /* try again */ }
    await new Promise((ok) => setTimeout(ok, 5000));
  }
  return lpTeams.names;
}
async function lpTeamName(base, team) {
  const k = teamKey(team); if (!k) return team;
  const names = await lpTeamNames(base);
  if (!names.length) return team;
  const scored = names.map((nm) => { const q = teamKey(nm); if (!q) return null; if (q === k) return { nm, d: 0 };
    if (Math.min(q.length, k.length) >= 3 && (q.startsWith(k) || k.startsWith(q))) return { nm, d: 1 + Math.abs(q.length - k.length) };
    if (Math.min(q.length, k.length) >= 4 && (q.includes(k) || k.includes(q))) return { nm, d: 50 + Math.abs(q.length - k.length) };
    return null; }).filter(Boolean).sort((a, b) => a.d - b.d);
  return scored.length ? scored[0].nm : team;
}
async function mapPool(team) {
  const base = process.env.FRAME_SRC; if (!base || !team) return null;          // not the desktop app: no map pool slides
  const k = team.toLowerCase(), hit = poolCache.get(k); if (hit && Date.now() - hit.at < 30 * 60 * 1000) return hit.data;
  try {
    const r = await fetch(`${base}/api/meta/maps?${new URLSearchParams({ team: await lpTeamName(base, team) })}`, { signal: AbortSignal.timeout(120000) });
    if (!r.ok) return { unavailable: true, mapStats: [] };
    const j = await r.json();
    if (!j || !Array.isArray(j.mapStats)) return { unavailable: true, mapStats: [] };
    const data = { team: j.team, matches: j.matches || 0, totalMaps: j.totalMaps || 0, partialData: !!j.partialData, partialRateLimited: !!j.partialRateLimited, mapStats: j.mapStats, matchList: (Array.isArray(j.matchList) ? j.matchList : []).slice(0, 10).map((x) => ({ date: x.date, opponent: x.opponent, event: x.event, maps: (x.maps || []).map((m) => ({ map: m.map, teamWon: m.teamWon })) })) };
    if (data.matches) poolCache.set(k, { at: Date.now(), data });          // an empty answer is not kept, so the next deck asks again
    return data;
  } catch { return { unavailable: true, mapStats: [] }; }
}
app.post('/api/pipeline/deck', guardPipeline, express.json({ limit: '120mb' }), async (req, res) => {          // the prep deck (.pptx) for one team, built from the exported rounds
  try {
    const b = req.body || {};
    if (!Array.isArray(b.rounds) || !b.rounds.length) return res.status(400).json({ error: 'No rounds received' });
    if (!String(b.team || '').trim()) return res.status(400).json({ error: 'No team given' });
    const pool = await mapPool(String(b.team).trim());          // map pool slide: the team's map record from R6 Prep (desktop app only); the slide is left out when there is nothing
    const buf = await require('./lib/deck').buildDeck({ rounds: b.rounds, team: String(b.team).trim(), title: String(b.title || 'Prep deck'), bans: b.bans && typeof b.bans === 'object' ? b.bans : {}, vods: b.vods && typeof b.vods === 'object' ? b.vods : {}, pool });
    res.type('application/vnd.openxmlformats-officedocument.presentationml.presentation').send(buf);
  } catch (e) { res.status(422).json({ error: e.message }); }
});

// VOD links for the game overview: asked from the R6 Prep server that runs next to this app in the desktop version (same Liquipedia lookup Prep uses)
app.get('/api/vods', async (req, res) => {
  const base = process.env.FRAME_SRC;
  if (!base) return res.status(503).json({ error: 'VOD lookup needs the desktop app with R6 Prep set up' });
  const team = String(req.query.team || '').trim();
  if (!team) return res.status(400).json({ error: 'No team given' });
  const day = (x) => (/^\d{4}-\d{2}-\d{2}$/.test(String(x || '')) ? String(x) : '');
  const qs = new URLSearchParams({ team: await lpTeamName(base, team) }); if (day(req.query.dateFrom)) qs.set('dateFrom', day(req.query.dateFrom)); if (day(req.query.dateTo)) qs.set('dateTo', day(req.query.dateTo));
  try {
    const r = await fetch(`${base}/api/local/series?${qs}`, { signal: AbortSignal.timeout(300000) });
    const j = await r.json().catch(() => ({}));
    if (r.status === 404) return res.status(503).json({ error: 'R6 Prep is an older version without VOD lookup: update the app' });
    if (!r.ok) return res.status(r.status === 503 ? 503 : 502).json({ error: j.message || j.error || 'Prep lookup failed' });
    res.json({ series: Array.isArray(j.series) ? j.series.map((x) => ({ date: x.date, opponent: x.opponent, event: x.event, vod: x.vod || null })) : [] });
  } catch (e) { res.status(502).json({ error: 'Could not reach R6 Prep' + (e && e.name === 'TimeoutError' ? ' (timed out)' : '') }); }
});

app.get('/api/summary', (req, res) => {
  const { team, map, site, side, result } = req.query, list = (x) => String(x || '').split(',').map((y) => y.trim()).filter(Boolean);
  res.json(summary(store.all(), { team, map, site, side, result, with: list(req.query.with), without: list(req.query.without), exact: req.query.exact === '1' }));
});

// Stored data: list the matches that are saved, and delete some of them or all of them.
app.get('/api/matches', (_req, res) => res.json({ matches: store.matches(), rounds: store.count() }));
app.post('/api/rounds/delete', guardUpload, express.json({ limit: '1mb' }), (req, res) => {
  const b = req.body || {};
  if (b.all === true) { const removed = store.removeMatches(null); return res.json({ removed, remaining: store.count() }); }
  if (!Array.isArray(b.matchIds) || !b.matchIds.length || !b.matchIds.every((x) => typeof x === 'string')) return res.status(400).json({ error: 'Choose at least one match to delete' });
  const removed = store.removeMatches(b.matchIds);
  res.json({ removed, remaining: store.count() });
});

app.get('/api/health', (_req, res) => res.json({ ok: true, rounds: store.count() }));

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(err.code === 'LIMIT_FILE_SIZE' ? 413 : 500).json({ error: err.message });
});

if (require.main === module) {
  app.listen(PORT, process.env.HOST || '0.0.0.0', () => console.log(`R6 Scout listening on :${PORT}`));
}
// desktop app: called once R6 Prep is starting, so Prep fetches Liquipedia's team list in the background and the first deck does not wait for it
app.warmLiquipedia = () => { const base = process.env.FRAME_SRC; if (base) lpTeamNames(base).catch(() => {}); };
module.exports = app;
