// Copies replay matches from the R6 Prep Input folder into Siege's own MatchReplay folder, so they can be watched in the game.
// Rules this file keeps:
//  - the Input folder is only read, never changed;
//  - a replay folder is copied under its own name, with its files unchanged (Siege will not read renamed replays);
//  - nothing in Siege's folder is overwritten, changed or removed: files are only ever added (as new folders);
//  - only a folder called MatchReplay is written to;
//  - nothing is copied while Siege is open, or when it cannot be told whether Siege is open;
//  - files still being copied into the Input folder are left until they stop changing.
const fs = require('fs');
const path = require('path');
const { execFile } = require('child_process');

const REC = /\.rec$/i;
const TMP = '.r6prep-tmp-';
const SETTLE_MS = 6000;               // a file changed this recently may still be arriving
const sizeSig = (files) => files.map((f) => f.name + ':' + f.size).sort().join('|');

function dateOf(name, mtime) {
  const m = /(\d{4})-(\d{2})-(\d{2})[_ T-](\d{2})-(\d{2})-(\d{2})/.exec(name);
  if (m) { const t = Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +m[6]); if (!isNaN(t)) return t; }
  return mtime || 0;
}

// Every match under root: a folder holding .rec files (one file per round). Loose .rec files are grouped by the part of their name before "-R<number>".
function findMatches(root, depth = 3) {
  const out = [];
  const walk = (dir, d) => {
    let ents; try { ents = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
    const recs = [];
    for (const e of ents) {
      if (e.name.startsWith('.')) continue;
      if (e.isFile() && REC.test(e.name)) { try { const s = fs.statSync(path.join(dir, e.name)); recs.push({ name: e.name, size: s.size, mtime: s.mtimeMs }); } catch { /* vanished */ } }
    }
    if (recs.length) {
      const groups = new Map(), isMatchDir = /^match/i.test(path.basename(dir));
      if (isMatchDir) groups.set(path.basename(dir), recs);
      else for (const f of recs) { const g = /^(.*)-R\d+\.rec$/i.exec(f.name); const k = g ? g[1] : path.basename(dir); if (!groups.has(k)) groups.set(k, []); groups.get(k).push(f); }
      for (const [name, files] of groups) {
        const mt = Math.max(...files.map((f) => f.mtime));
        out.push({ name, dir, files, loose: !isMatchDir, date: dateOf(name, mt), mtime: mt, sig: sizeSig(files) });
      }
      return;                                   // a match folder is not searched further
    }
    if (d < depth) for (const e of ents) if (e.isDirectory() && !e.name.startsWith('.')) walk(path.join(dir, e.name), d + 1);
  };
  walk(root, 0);
  const seen = new Set();
  return out.filter((m) => (seen.has(m.name) ? false : seen.add(m.name))).sort((a, b) => b.date - a.date || (a.name < b.name ? 1 : -1));
}

// Siege's folder: each match is a direct subfolder holding .rec files.
function siegeMatches(root) {
  let ents; try { ents = fs.readdirSync(root, { withFileTypes: true }); } catch { return []; }
  const out = [];
  for (const e of ents) {
    if (!e.isDirectory() || e.name.startsWith(TMP)) continue;
    const dir = path.join(root, e.name), files = [];
    try { for (const f of fs.readdirSync(dir, { withFileTypes: true })) if (f.isFile() && REC.test(f.name)) { const s = fs.statSync(path.join(dir, f.name)); files.push({ name: f.name, size: s.size, mtime: s.mtimeMs }); } } catch { continue; }
    if (!files.length) continue;
    const mt = Math.max(...files.map((f) => f.mtime));
    out.push({ name: e.name, dir, files, date: dateOf(e.name, mt), mtime: mt, sig: sizeSig(files) });
  }
  return out.sort((a, b) => b.date - a.date);
}

// What a sync would do. Pure: only reads.
function plan(lib, siege, keep, now = Date.now()) {
  const sMap = new Map(siege.map((m) => [m.name, m]));
  const present = [], conflicts = [], pending = [], settling = [];
  for (const m of lib) {
    const s = sMap.get(m.name);
    if (s) { (s.sig === m.sig ? present : conflicts).push(m); continue; }
    if (now - m.mtime < SETTLE_MS) { settling.push(m); continue; }
    pending.push(m);
  }
  const libNames = new Map(lib.map((m) => [m.name, m]));
  const own = siege.filter((s) => !libNames.has(s.name) || libNames.get(s.name).sig !== s.sig);
  let free = Math.max(0, keep - siege.length);
  const copy = [], remove = [], waiting = [];                  // nothing in Siege is ever removed: what does not fit waits
  for (const m of pending) { if (free > 0) { copy.push(m); free--; } else waiting.push(m); }          // newest first
  return { copy, remove, waiting, conflicts, settling, present, own, siegeCount: siege.length };
}

const copyDir = (m, siegeRoot) => {
  const tmp = path.join(siegeRoot, TMP + m.name), fin = path.join(siegeRoot, m.name);
  if (fs.existsSync(fin)) throw new Error('already in Siege: ' + m.name);
  fs.rmSync(tmp, { recursive: true, force: true });
  fs.mkdirSync(tmp);
  try {
    for (const f of m.files) fs.copyFileSync(path.join(m.dir, f.name), path.join(tmp, f.name));
    const back = sigOf(tmp, m);                          // the copy must have the same files and sizes as the original
    if (back !== m.sig) throw new Error('copy does not match the original: ' + m.name);
    fs.renameSync(tmp, fin);
  } catch (e) { fs.rmSync(tmp, { recursive: true, force: true }); throw e; }
};
const sigOf = (dir, m) => sizeSig(m.files.map((f) => { const s = fs.statSync(path.join(dir, f.name)); return { name: f.name, size: s.size }; }));

// Does a plan still hold right before acting? (files can change while we wait)
const stable = (m) => { try { return m.files.every((f) => { const s = fs.statSync(path.join(m.dir, f.name)); return s.size === f.size && Date.now() - s.mtimeMs >= SETTLE_MS; }); } catch { return false; } };

// Run one sync. Returns what was done. dry = only report the plan.
function sync({ library, siege, keep = 30, dry = false }) {
  const res = { copied: [], removed: [], waiting: [], conflicts: [], settling: [], errors: [], present: 0, own: 0, siegeCount: 0 };
  if (!library || !fs.existsSync(library)) { res.errors.push('The Input folder is missing'); return res; }
  if (!siege || !fs.existsSync(siege) || !fs.statSync(siege).isDirectory()) { res.errors.push("Siege's replay folder is missing"); return res; }
  if (path.basename(siege).toLowerCase() !== 'matchreplay') { res.errors.push("Siege's replay folder must be the folder called MatchReplay"); return res; }
  try { for (const e of fs.readdirSync(siege)) if (e.startsWith(TMP)) fs.rmSync(path.join(siege, e), { recursive: true, force: true }); } catch { /* ignore */ }          // left over from a copy that was cut short
  const lib = findMatches(library), s = siegeMatches(siege), p = plan(lib, s, keep);
  res.waiting = p.waiting.map((m) => m.name); res.conflicts = p.conflicts.map((m) => m.name); res.settling = p.settling.map((m) => m.name);
  res.present = p.present.length; res.own = p.own.length; res.siegeCount = p.siegeCount;
  if (dry) { res.copied = p.copy.map((m) => m.name); res.removed = p.remove.map((m) => m.name); return res; }
  for (const m of p.copy) {
    if (!stable(m)) { res.settling.push(m.name); continue; }
    try {
      if (siegeMatches(siege).length >= keep) { res.waiting.push(m.name); continue; }          // full: leave it, never make room by deleting
      copyDir(m, siege); res.copied.push(m.name);
    } catch (e) { res.errors.push(String(e.message || e)); }
  }
  const after = siegeMatches(siege), aMap = new Map(after.map((m) => [m.name, m]));          // report how things stand now
  res.siegeCount = after.length; res.present = findMatches(library).filter((m) => aMap.has(m.name) && aMap.get(m.name).sig === m.sig).length;
  return res;
}

// Common places Siege keeps its replays (PC). Only folders that exist are returned.
function siegeCandidates(env = process.env) {
  // The game folder has been called both "Tom Clancy's Rainbow Six Siege" and "Tom Clancy's Rainbow Six Siege X", so any folder
  // starting with that name is looked at.
  const out = [], is = /^Tom Clancy.s Rainbow Six Siege/i;
  const roots = [env['ProgramFiles(x86)'], env.ProgramFiles, 'C:\\Program Files (x86)', 'C:\\Program Files'].filter(Boolean);
  for (const d of 'CDEFG') roots.push(d + ':\\');
  const parents = [['Ubisoft', 'Ubisoft Game Launcher', 'games'], ['Ubisoft Game Launcher', 'games'], ['Steam', 'steamapps', 'common'], ['SteamLibrary', 'steamapps', 'common'], ['Games', 'Ubisoft', 'games']];
  for (const r of roots) for (const rel of parents) {
    const dir = path.join(r, ...rel);
    let names = []; try { names = fs.readdirSync(dir); } catch { continue; }
    for (const n of names.filter((x) => is.test(x)).sort()) {
      const p = path.join(dir, n, 'MatchReplay');
      try { if (fs.statSync(p).isDirectory() && !out.includes(p)) out.push(p); } catch { /* not there */ }
    }
  }
  return out;
}

// Is Siege running? Only the list of running programs is read. Answers true, false, or null when that cannot be found out
// (null is treated like true: nothing is copied).
function siegeRunning() {
  return new Promise((resolve) => {
    if (process.platform !== 'win32') return resolve(false);
    execFile('tasklist', ['/FO', 'CSV', '/NH'], { windowsHide: true, timeout: 8000, maxBuffer: 8e6 }, (err, out) => {
      const t = String(out || '');
      if (err || !/"[^"]+\.exe"/i.test(t)) return resolve(null);
      resolve(/^"[^"]*(rainbowsix|siege)[^"]*\.exe"/im.test(t));
    });
  });
}

module.exports = { findMatches, siegeMatches, plan, sync, siegeCandidates, siegeRunning, SETTLE_MS, TMP };
