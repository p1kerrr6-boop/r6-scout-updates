// Phone / tablet access: lets other devices on the same network open R6 Prep from this PC.
// It is OFF until switched on in the app. When on, a second listener answers on the network, behind a PIN,
// and only for looking at the data (plus saving playlists). Uploads, deleting data, the folder routes and R6 Prep stay on this PC.
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');
const crypto = require('crypto');
const vault = require('../lib/vault');

const PREF_PORT = 38412;
const COOKIE = 'r6lan';
const MONTH = 30 * 24 * 3600;

const newPin = () => String(crypto.randomInt(0, 1000000)).padStart(6, '0');
const hmac = (secret, pin) => crypto.createHmac('sha256', secret).update('r6lan:' + pin).digest('hex');
const same = (a, b) => { const x = Buffer.from(String(a)), y = Buffer.from(String(b)); return x.length === y.length && crypto.timingSafeEqual(x, y); };

// this computer's addresses on the local network (not the loopback one), private ranges first
function addresses() {
  const out = [];
  for (const list of Object.values(os.networkInterfaces())) for (const a of list || []) {
    if (a.family !== 'IPv4' || a.internal) continue;
    const priv = /^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(a.address);
    out.push({ address: a.address, priv });
  }
  return out.sort((a, b) => Number(b.priv) - Number(a.priv)).map((a) => a.address);
}

const PAGE = (msg) => `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>R6 Prep</title><meta name="theme-color" content="#0f1115"><link rel="manifest" href="/manifest.webmanifest"><link rel="apple-touch-icon" href="/icon-192.png">
<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#f5f5f2;color:#1c1e22;font:16px system-ui,sans-serif}
form{width:min(340px,86vw);display:grid;gap:14px}h1{margin:0;font-size:22px}p{margin:0;color:#6b6e75;font-size:14px}
input{font:inherit;font-size:26px;letter-spacing:.3em;text-align:center;padding:12px;border-radius:10px;border:1px solid #e0e0da;background:#fff;color:#1c1e22}
button{font:inherit;font-weight:700;padding:13px;border:0;border-radius:10px;background:#1c1e22;color:#fff}.err{color:#ad1f1f}</style></head>
<body><form method="post" action="/lan/login"><h1>R6 <span style="color:#6b6e75;font-weight:600">PREP</span></h1><p>Type the 6 digit PIN shown on the computer.</p>
<input name="pin" inputmode="numeric" autocomplete="one-time-code" maxlength="6" pattern="[0-9]{6}" autofocus required aria-label="PIN">
${msg ? `<p class="err">${msg}</p>` : ''}<button type="submit">Open</button></form></body></html>`;

// the writes a tablet may make: playlists only
const canWrite = (req) => /^\/api\/playlists(\/|$)/.test(req.path);

function create({ expressApp, express, userData }) {
  const file = path.join(userData, 'lan.json');
  const load = () => { try { return JSON.parse(vault.readText(file)) || {}; } catch { return {}; } };
  let st = load();
  if (!/^\d{6}$/.test(st.pin || '') || !st.secret) { st = { enabled: false, ...st, pin: newPin(), secret: crypto.randomBytes(32).toString('hex') }; }
  const save = () => { try { vault.writeText(file, JSON.stringify(st)); } catch { /* read-only profile: lives until the app closes */ } };
  save();

  let server = null, port = 0;
  const fails = new Map();          // ip -> [times of wrong PINs]

  const app = express();
  app.disable('x-powered-by');
  app.use((req, res, next) => {
    res.set({ 'X-Content-Type-Options': 'nosniff', 'Cache-Control': 'no-store' });
    if (req.path.startsWith('/desktop')) return res.status(404).end();          // folder picking and settings belong to this PC
    next();
  });
  // public pieces: the icon and manifest (browsers fetch them without cookies) and the PIN page
  app.get(['/manifest.webmanifest', '/icon-192.png', '/icon-512.png', '/logo.png'], (req, res, next) => { res.set('Cache-Control', 'public, max-age=3600'); next(); }, express.static(path.join(__dirname, '..', 'public')));
  app.get('/lan/login', (_req, res) => res.type('html').send(PAGE('')));
  app.post('/lan/login', express.urlencoded({ extended: false, limit: '1kb' }), (req, res) => {
    const now = Date.now(), recent = (fails.get(req.ip) || []).filter((t) => now - t < 10 * 60 * 1000);
    if (recent.length >= 8) return res.status(429).type('html').send(PAGE('Too many wrong PINs. Wait a few minutes.'));
    if (!same(String((req.body || {}).pin || '').trim(), st.pin)) { recent.push(now); fails.set(req.ip, recent); return res.status(401).type('html').send(PAGE('That PIN is not right.')); }
    fails.delete(req.ip);
    res.set('Set-Cookie', `${COOKIE}=${hmac(st.secret, st.pin)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${MONTH}`);
    res.redirect(303, '/');
  });
  const cookieOf = (req) => { const m = new RegExp('(?:^|; )' + COOKIE + '=([0-9a-f]+)').exec(req.headers.cookie || ''); return m ? m[1] : ''; };
  app.use((req, res, next) => {
    if (!same(cookieOf(req), hmac(st.secret, st.pin))) {
      if (req.path.startsWith('/api/')) return res.status(401).json({ error: 'PIN needed' });
      return res.redirect(303, '/lan/login');
    }
    if (!['GET', 'HEAD'].includes(req.method) && !canWrite(req)) return res.status(403).json({ error: 'That can only be done on the computer running R6 Prep.' });
    next();
  });
  app.get('/api/lan', (_req, res) => res.json({ lan: true }));          // lets the page know it is on a phone or tablet
  app.use((req, _res, next) => { req.r6lan = true; next(); });
  app.use(expressApp);

  const url = () => addresses().map((a) => `http://${a}:${port}/`);
  const status = () => ({ enabled: Boolean(server), port, urls: server ? url() : [], pin: st.pin });
  const listen = (p) => new Promise((resolve, reject) => {
    const s = http.createServer(app);
    s.once('error', reject);
    s.listen(p, '0.0.0.0', () => { server = s; port = s.address().port; resolve(); });
  });
  async function enable() {
    if (server) return status();
    try { await listen(PREF_PORT); } catch { await listen(0); }
    st.enabled = true; save(); return status();
  }
  async function close() {
    if (server) { const s = server; server = null; port = 0; s.closeAllConnections && s.closeAllConnections(); await new Promise((r) => s.close(r)); }
  }
  async function disable() { st.enabled = false; save(); await close(); return status(); }
  async function newCode() {          // a new PIN also signs out every device that was let in with the old one
    st.pin = newPin(); st.secret = crypto.randomBytes(32).toString('hex'); save(); return status();
  }
  return { enable, disable, newCode, status, close, startIfOn: () => (st.enabled ? enable().catch(() => {}) : null) };
}

// the settings routes, answered only to this PC's own window (same checks as the folder routes)
function addRoutes(expressApp, express, lan) {
  const guard = (req, res, next) => (req.headers['x-r6-desktop'] === '1' && (!req.headers.origin || req.headers.origin === `http://127.0.0.1:${process.env.PORT}`)) ? next() : res.status(403).json({ error: 'forbidden' });
  expressApp.get('/desktop/lan', guard, (_req, res) => res.json(lan.status()));
  expressApp.post('/desktop/lan', guard, express.json(), async (req, res) => {
    const b = req.body || {};
    try { if (b.newCode) await lan.newCode(); if (b.enabled === true) await lan.enable(); else if (b.enabled === false) await lan.disable(); res.json(lan.status()); }
    catch (e) { res.status(500).json({ error: String((e && e.message) || e) }); }
  });
}

module.exports = { create, addresses, addRoutes };
