const express = require('express');
const multer = require('multer');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const store = require('./lib/store');
const jobs = require('./lib/jobs');
const { summary } = require('./lib/analyze');
const pipeline = require('./lib/pipeline');
const playlists = require('./lib/playlists');
const players = require('./lib/players');
const charts = require('./lib/targetcharts');

const app = express();
const PORT = process.env.PORT || 3000;

const upload = multer({
  storage: multer.diskStorage({
    destination: os.tmpdir(),
    filename: (_req, _file, cb) => cb(null, `r6up-${crypto.randomUUID()}.rec`), // never trust the client's name on disk
  }),
  limits: { fileSize: 150 * 1024 * 1024, files: 100 },
  fileFilter: (_req, file, cb) => cb(null, /\.rec$/i.test(file.originalname)),
});

app.set('trust proxy', 1);
app.disable('x-powered-by');
app.use((_req, res, next) => {
  res.set({
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'Referrer-Policy': 'no-referrer',
    'Content-Security-Policy': "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'" + (process.env.FRAME_SRC ? `; frame-src ${process.env.FRAME_SRC}` : ''),
  });
  next();
});

// Only this app's own pages may talk to the server. In the desktop app (R6_LOOPBACK_ONLY) the address must be this computer's own, which stops
// other websites from reaching it through DNS rebinding; and any request that changes something must come from the same address as the page.
// Phones and tablets let in through the LAN switch (lan.js) are checked by their PIN instead and skip the address test.
app.use((req, res, next) => {
  const host = String(req.headers.host || '').toLowerCase();
  if (process.env.R6_LOOPBACK_ONLY && !req.r6lan && !/^(127\.0\.0\.1|localhost|\[::1\]):\d+$/.test(host)) return res.status(403).json({ error: 'forbidden' });
  const o = req.headers.origin;
  if (o && !['GET', 'HEAD', 'OPTIONS'].includes(req.method)) {
    let oh = ''; try { oh = new URL(o).host.toLowerCase(); } catch { /* not a URL */ }
    if (oh !== host) return res.status(403).json({ error: 'forbidden' });
  }
  next();
});

// Uploads: if UPLOAD_KEY is set, a matching x-upload-key header is required. Also a small per-IP rate limit.
const UPLOAD_KEY = process.env.UPLOAD_KEY || '';
function sameKey(a, b) {
  const x = Buffer.from(String(a)), y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}
const hits = new Map();
function guardUpload(req, res, next) {
  if (UPLOAD_KEY && !sameKey(req.get('x-upload-key') || '', UPLOAD_KEY)) return res.status(401).json({ error: 'Upload key required' });
  const now = Date.now(), win = 10 * 60 * 1000, max = +process.env.UPLOAD_RATE || 30;
  const arr = (hits.get(req.ip) || []).filter((t) => now - t < win);
  if (arr.length >= max) return res.status(429).json({ error: 'Too many uploads, try again later' });
  arr.push(now);
  hits.set(req.ip, arr);
  next();
}
setInterval(() => { const now = Date.now(); for (const [ip, a] of hits) if (!a.some((t) => now - t < 600000)) hits.delete(ip); }, 600000).unref();

app.use(express.static(path.join(__dirname, 'public')));

// Upload one or more round files (a match is a folder of per-round .rec files).
app.post('/api/upload', guardUpload, upload.array('files', 100), (req, res) => {
  if (!req.files || !req.files.length) return res.status(400).json({ error: 'No .rec files received' });
  // sort by name so R01..R15 get sensible fallback numbering
  const files = req.files.slice().sort((a, b) => a.originalname.localeCompare(b.originalname));
  const job = jobs.createJob(files);
  res.status(202).json({ jobId: job.id, total: job.total });
});

app.get('/api/jobs/:id', (req, res) => {
  const job = jobs.getJob(req.params.id);
  if (!job) return res.status(404).json({ error: 'Unknown job' });
  res.json(job);
});

// Batch pipeline: one replay in, its round data and map images out (the page writes them into the folder the user picked).
// Stateless: nothing from the replay is kept on the server unless ?store=1 asks for the round to be added to the app's data.
const pipeHits = new Map();
function guardPipeline(req, res, next) {
  if (UPLOAD_KEY && !sameKey(req.get('x-upload-key') || '', UPLOAD_KEY)) return res.status(401).json({ error: 'Upload key required' });
  const now = Date.now(), win = 10 * 60 * 1000, max = +process.env.PIPELINE_RATE || 600;
  const arr = (pipeHits.get(req.ip) || []).filter((t) => now - t < win);
  if (arr.length >= max) return res.status(429).json({ error: 'Too many files, try again later' });
  arr.push(now); pipeHits.set(req.ip, arr);
  next();
}
app.post('/api/pipeline/process', guardPipeline, upload.single('file'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No .rec file received' });
  try {
    const name = path.basename(String(req.body.name || req.file.originalname || 'x.rec'));
    let edits = null;
    try { if (req.body.edits) edits = JSON.parse(req.body.edits); } catch { edits = null; }
    const { round, files, mapSlug, dir, data } = await pipeline.processRec(req.file.path, name, 1, { width: Math.min(+req.body.width || 1800, 2576), images: req.body.images !== '0', plain: req.body.plain === '1', droneImages: req.body.droneImages !== '0', timeline: String(req.body.timeline === undefined ? 'key' : req.body.timeline).slice(0, 80), edits });
    const added = req.query.store === '1' ? store.addMany([round]) : 0;
    res.json({ id: round.id, mapSlug, dir, data, map: round.map, round: round.roundNumber, summary: pipeline.summaryOf(round), added, files: files.map((f) => ({ name: f.name, b64: f.data.toString('base64') })) });
  } catch (e) {
    res.status(422).json({ error: e.message });
  } finally {
    require('fs').rm(req.file.path, { force: true }, () => {});
  }
});
app.post('/api/pipeline/gallery', guardPipeline, express.json({ limit: '5mb' }), (req, res) => {
  res.type('html').send(pipeline.galleryHtml(Array.isArray(req.body && req.body.entries) ? req.body.entries : []));
});

// a team's map pool from the R6 Prep server that runs next to this app in the desktop version (the same Liquipedia numbers Prep shows); kept for 30 minutes, never blocks a deck
const poolCache = new Map();
// Team names: the replays say "Geekay", Liquipedia says "Geekay Esports" (or "Team Falcons" vs "Falcons"). Ask Prep for the names Liquipedia knows and pick the closest one, so a different spelling still finds the team.
const teamKey = (n) => String(n || '').normalize('NFKD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/\b(team|esports?|gaming|club|clan)\b/g, '').replace(/[^a-z0-9]/g, '');
let lpTeams = { at: 0, names: [] };
async function lpTeamNames(base) {
  if (lpTeams.names.length && Date.now() - lpTeams.at < 60 * 60 * 1000) return lpTeams.names;
  for (let n = 0; n < 24; n++) {                                            // Prep builds its team list in the background on first use: wait for it (about 2 min at most)
    try {
      const r = await fetch(`${base}/api/meta/teams`, { signal: AbortSignal.timeout(20000) });
      const j = r.ok ? await r.json() : null;
      const names = j && Array.isArray(j.allTeams) ? j.allTeams.filter((x) => typeof x === 'string') : [];
      if (names.length && (!j.loading || n >= 6)) { lpTeams = { at: Date.now(), names }; return names; }
    } catch { /* try again */ }
    await new Promise((ok) => setTimeout(ok, 5000));
  }
  return lpTeams.names;
}
async function lpTeamName(base, team) {
  const k = teamKey(team); if (!k) return team;
  const names = await lpTeamNames(base);
  if (!names.length) return team;
  const scored = names.map((nm) => { const q = teamKey(nm); if (!q) return null; if (q === k) return { nm, d: 0 };
    if (Math.min(q.length, k.length) >= 3 && (q.startsWith(k) || k.startsWith(q))) return { nm, d: 1 + Math.abs(q.length - k.length) };
    if (Math.min(q.length, k.length) >= 4 && (q.includes(k) || k.includes(q))) return { nm, d: 50 + Math.abs(q.length - k.length) };
    return null; }).filter(Boolean).sort((a, b) => a.d - b.d);
  return scored.length ? scored[0].nm : team;
}
async function mapPool(team) {
  const base = process.env.FRAME_SRC; if (!base || !team) return null;          // not the desktop app: no map pool slides
  const k = team.toLowerCase(), hit = poolCache.get(k); if (hit && Date.now() - hit.at < 30 * 60 * 1000) return hit.data;
  try {
    const r = await fetch(`${base}/api/meta/maps?${new URLSearchParams({ team: await lpTeamName(base, team) })}`, { signal: AbortSignal.timeout(120000) });
    if (!r.ok) return { unavailable: true, mapStats: [] };
    const j = await r.json();
    if (!j || !Array.isArray(j.mapStats)) return { unavailable: true, mapStats: [] };
    const data = { team: j.team, matches: j.matches || 0, totalMaps: j.totalMaps || 0, partialData: !!j.partialData, partialRateLimited: !!j.partialRateLimited, mapStats: j.mapStats, matchList: (Array.isArray(j.matchList) ? j.matchList : []).slice(0, 10).map((x) => ({ date: x.date, opponent: x.opponent, event: x.event, maps: (x.maps || []).map((m) => ({ map: m.map, teamWon: m.teamWon })) })) };
    if (data.matches) poolCache.set(k, { at: Date.now(), data });          // an empty answer is not kept, so the next deck asks again
    return data;
  } catch { return { unavailable: true, mapStats: [] }; }
}
app.post('/api/pipeline/deck', guardPipeline, express.json({ limit: '120mb' }), async (req, res) => {          // the prep deck (.pptx) for one team, built from the exported rounds
  try {
    const b = req.body || {};
    if (!Array.isArray(b.rounds) || !b.rounds.length) return res.status(400).json({ error: 'No rounds received' });
    if (!String(b.team || '').trim()) return res.status(400).json({ error: 'No team given' });
    const pool = await mapPool(String(b.team).trim());          // map pool slide: the team's map record from R6 Prep (desktop app only); the slide is left out when there is nothing
    const buf = await require('./lib/deck').buildDeck({ rounds: b.rounds, team: String(b.team).trim(), title: String(b.title || 'Prep deck'), bans: b.bans && typeof b.bans === 'object' ? b.bans : {}, vods: b.vods && typeof b.vods === 'object' ? b.vods : {}, pool });
    res.type('application/vnd.openxmlformats-officedocument.presentationml.presentation').send(buf);
  } catch (e) { res.status(422).json({ error: e.message }); }
});

// VOD links for the game overview: asked from the R6 Prep server that runs next to this app in the desktop version (same Liquipedia lookup Prep uses)
app.get('/api/vods', async (req, res) => {
  const base = process.env.FRAME_SRC;
  if (!base) return res.status(503).json({ error: 'VOD lookup needs the desktop app with R6 Prep set up' });
  const team = String(req.query.team || '').trim();
  if (!team) return res.status(400).json({ error: 'No team given' });
  const day = (x) => (/^\d{4}-\d{2}-\d{2}$/.test(String(x || '')) ? String(x) : '');
  const qs = new URLSearchParams({ team: await lpTeamName(base, team) }); if (day(req.query.dateFrom)) qs.set('dateFrom', day(req.query.dateFrom)); if (day(req.query.dateTo)) qs.set('dateTo', day(req.query.dateTo));
  try {
    const r = await fetch(`${base}/api/local/series?${qs}`, { signal: AbortSignal.timeout(300000) });
    const j = await r.json().catch(() => ({}));
    if (r.status === 404) return res.status(503).json({ error: 'R6 Prep is an older version without VOD lookup: update the app' });
    if (!r.ok) return res.status(r.status === 503 ? 503 : 502).json({ error: j.message || j.error || 'Prep lookup failed' });
    res.json({ series: Array.isArray(j.series) ? j.series.map((x) => ({ date: x.date, opponent: x.opponent, event: x.event, vod: x.vod || null })) : [] });
  } catch (e) { res.status(502).json({ error: 'Could not reach R6 Prep' + (e && e.name === 'TimeoutError' ? ' (timed out)' : '') }); }
});

app.get('/api/summary', (req, res) => {
  const { team, map, site, side, result } = req.query, list = (x) => String(x || '').split(',').map((y) => y.trim()).filter(Boolean);
  res.json(summary(store.all(), { team, map, site, side, result, with: list(req.query.with), without: list(req.query.without), exact: req.query.exact === '1' }));
});

// Players and Targets: who plays where and who dies first, for one team, from the position tracks. Filters: team, map, site, side, time window, movement, dates, and which games.
app.get('/api/players', (req, res) => {
  try {
    const q = req.query, list = (x) => String(x || '').split(',').map((y) => y.trim()).filter(Boolean), dayOk = (x) => (/^\d{4}-\d{2}-\d{2}$/.test(String(x || '')) ? String(x) : '');
    const all = store.all(), out = { facets: players.facets(all) };
    const team = String(q.team || '').trim();
    if (team) {
      const o = { team, map: q.map || 'all', site: q.site || 'all', side: q.side === 'Attack' ? 'Attack' : 'Defense', win: q.win, move: list(q.move), from: dayOk(q.from), to: dayOk(q.to), matches: list(q.matches) };
      out.games = players.games(all, o); out.result = players.analyze(all, o); out.charts = { timeline: charts.timeline(out.result), cumulative: charts.cumulative(out.result), winrate: charts.winrate(out.result) }; out.query = { team: o.team, map: o.map, site: o.site, side: o.side };
    }
    res.json(out);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Round Viewer: the games and rounds to pick from, and one round with the position tracks the replay needs.
const trackOk = (u) => u.k === 'p' && Array.isArray(u.ts) && Array.isArray(u.pf);
app.get('/api/viewer/games', (_req, res) => {
  try {
    const by = new Map();
    for (const r of store.all()) {
      const g = by.get(r.matchId) || { matchId: r.matchId, map: r.map, ts: r.timestamp || '', teams: [], rounds: [] };
      for (const t of r.teams || []) if (t.name && !g.teams.includes(t.name)) g.teams.push(t.name);
      if (r.timestamp && (!g.ts || r.timestamp < g.ts)) g.ts = r.timestamp;
      const def = (r.teams || []).find((t) => t.role === 'Defense'), atk = (r.teams || []).find((t) => t.role === 'Attack');
      g.rounds.push({ id: r.id, n: r.roundNumber, site: r.site || '', winner: r.winner || '', def: def ? def.name : '', atk: atk ? atk.name : '', tracks: (r.utility || []).some(trackOk) });
      by.set(r.matchId, g);
    }
    const games = [...by.values()].map((g) => ({ ...g, rounds: g.rounds.sort((a, b) => (a.n || 0) - (b.n || 0)) })).sort((a, b) => String(b.ts).localeCompare(String(a.ts)));
    res.json({ games });
  } catch (e) { res.status(500).json({ error: e.message }); }
});
app.get('/api/viewer/round', (req, res) => {
  try {
    const id = String(req.query.id || ''), r = store.all().find((x) => x.id === id);
    if (!r) return res.status(404).json({ error: 'Round not found' });
    const u = r.utility || [];
    res.json({
      id: r.id, matchId: r.matchId, n: r.roundNumber, map: r.map, site: r.site || '', date: r.timestamp || '', teams: r.teams || [], winner: r.winner || '', players: r.players || [], kills: r.kills || [],
      tracks: u.filter(trackOk).map((x) => ({ who: x.who, op: x.op, side: x.side, ts: x.ts, pf: x.pf, dt: x.dt == null ? null : x.dt })),
      drones: u.filter((x) => x.k === 'g' && /drone/i.test(x.op || '') && Array.isArray(x.pf)).map((x) => ({ op: x.op, pf: x.pf })),
    });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// Playlists: saved lists of rounds. Writes need the upload key when one is set (no rate limit, they are small).
const guardWrite = (req, res, next) => (UPLOAD_KEY && !sameKey(req.get('x-upload-key') || '', UPLOAD_KEY) ? res.status(401).json({ error: 'Upload key required' }) : next());
const jsonBody = express.json({ limit: '1mb' });
function playlistView(p) {          // each entry with what the round was: map, site, who it was against, result and line-up, from the stored rounds
  const byId = new Map(store.all().map((r) => [r.id, r]));
  return { id: p.id, name: p.name, created: p.created, entries: p.entries.map((e) => {
    const r = byId.get(e.id); if (!r) return { ...e, missing: true };
    const mine = (r.players || []).filter((x) => x.team === e.team), opp = (r.teams || []).map((t) => t.name).find((n) => n && n !== e.team) || '';
    const side = (mine[0] && mine[0].side) || ((r.teams || []).find((t) => t.name === e.team) || {}).role || '';
    return { ...e, map: r.map, site: r.site, round: r.roundNumber, date: String(r.timestamp || '').slice(0, 10), opponent: opp, side, won: r.winner === e.team, ops: mine.map((x) => x.operator).filter(Boolean) };
  }) };
}
const pl = (fn) => (req, res) => { try { res.json(fn(req) || { ok: true }); } catch (e) { res.status(e.message === 'Playlist not found' ? 404 : 400).json({ error: e.message }); } };
app.get('/api/playlists', (_req, res) => res.json({ playlists: playlists.list().map(playlistView) }));
app.post('/api/playlists', guardWrite, jsonBody, pl((req) => { const p = playlists.create((req.body || {}).name, (req.body || {}).entries); return { id: p.id, playlists: playlists.list().map(playlistView) }; }));
app.post('/api/playlists/:id/add', guardWrite, jsonBody, pl((req) => ({ added: playlists.addEntries(req.params.id, (req.body || {}).entries) })));
app.post('/api/playlists/:id/remove', guardWrite, jsonBody, pl((req) => playlists.removeEntry(req.params.id, String((req.body || {}).roundId || ''), String((req.body || {}).team || ''))));
app.post('/api/playlists/:id/note', guardWrite, jsonBody, pl((req) => playlists.setNote(req.params.id, String((req.body || {}).roundId || ''), String((req.body || {}).team || ''), (req.body || {}).note)));
app.post('/api/playlists/:id/rename', guardWrite, jsonBody, pl((req) => playlists.rename(req.params.id, (req.body || {}).name)));
app.post('/api/playlists/:id/delete', guardWrite, pl((req) => playlists.remove(req.params.id)));
app.post('/api/playlists/:id/deck', guardPipeline, jsonBody, async (req, res) => {          // the prep deck for one team from the rounds of a playlist
  try {
    const p = playlists.find(req.params.id); if (!p) return res.status(404).json({ error: 'Playlist not found' });
    const team = String((req.body || {}).team || '').trim(); if (!team) return res.status(400).json({ error: 'No team given' });
    const have = new Map(store.all().map((r) => [r.id, r])), rounds = [...new Set(p.entries.filter((e) => e.team === team).map((e) => e.id))].map((id) => have.get(id)).filter(Boolean);
    if (!rounds.length) return res.status(400).json({ error: 'No saved rounds for ' + team + ' in this playlist' });
    const buf = await require('./lib/deck').buildDeck({ rounds, team, title: p.name, bans: {}, vods: {}, pool: null });
    res.type('application/vnd.openxmlformats-officedocument.presentationml.presentation').send(buf);
  } catch (e) { res.status(422).json({ error: e.message }); }
});

// Stored data: list the matches that are saved, and delete some of them or all of them.
app.get('/api/matches', (_req, res) => res.json({ matches: store.matches(), rounds: store.count() }));
app.post('/api/rounds/delete', guardUpload, express.json({ limit: '1mb' }), (req, res) => {
  const b = req.body || {};
  if (b.all === true) { const removed = store.removeMatches(null); return res.json({ removed, remaining: store.count() }); }
  if (!Array.isArray(b.matchIds) || !b.matchIds.length || !b.matchIds.every((x) => typeof x === 'string')) return res.status(400).json({ error: 'Choose at least one match to delete' });
  const removed = store.removeMatches(b.matchIds);
  res.json({ removed, remaining: store.count() });
});

app.get('/api/health', (_req, res) => res.json({ ok: true, rounds: store.count(), problem: store.problem() || undefined, encrypted: require('./lib/vault').status().active }));

app.use((err, _req, res, _next) => {
  const bad = err.type === 'entity.parse.failed' || err.status === 400, big = err.code === 'LIMIT_FILE_SIZE' || err.type === 'entity.too.large';
  if (!bad && !big) console.error(err);
  res.status(big ? 413 : bad ? 400 : 500).json({ error: bad ? 'That request was not valid JSON' : big ? 'That is too big to upload' : err.message });
});

if (require.main === module) {
  app.listen(PORT, process.env.HOST || '0.0.0.0', () => console.log(`R6 Scout listening on :${PORT}`));
}
// desktop app: called once R6 Prep is starting, so Prep fetches Liquipedia's team list in the background and the first deck does not wait for it
app.warmLiquipedia = () => { const base = process.env.FRAME_SRC; if (base) lpTeamNames(base).catch(() => {}); };
module.exports = app;
