"""Snap raw reinforcement objects onto the blueprint's reinforceable wall slots (grey rectangles).
Items get fx/fy (raw position, 0..1 of the blueprint), and for reinforcements: sx/sy (slot segment centre), a (angle),
ln/th (segment length/thickness, fraction of image width), sid/seg/cx/cy (slot id, segment index, slot centre) or become
barricades (k='h') when no wall slot is near and the object sits in a wall opening."""
import math, os, numpy as np
from scipy import ndimage as ndi
from PIL import Image
HERE = os.path.dirname(os.path.abspath(__file__))
_cache = {}
SEG = 58.0

def north_lift(floor, y):
    """1F: the blueprint's northern half sits a little higher than the plain scale predicts. Standing-still tests (Tellers doorframe, bathroom corner)
    were 0.5 m and 1.0 m too far down; a lift growing by 2.2 px per metre north of y = -83 fixes both and leaves the rest of the floor untouched."""
    return 2.2 * (y + 83.0) if floor == 'ground' and y > -83.0 else 0.0

def _load(cfg, floor):
    key = (cfg['name'], floor)
    if key in _cache: return _cache[key]
    fl = cfg['floors'][floor]
    g = np.array(Image.open(os.path.join(HERE, '..', '..', 'public', fl['image'].lstrip('/'))).convert('L')).astype(int)
    lo, hi = fl['slotGrey']
    m = ndi.binary_opening((g >= lo) & (g <= hi), structure=np.ones((3, 3)))
    lab, n = ndi.label(m, structure=np.ones((3, 3))); slots = []
    for i in range(1, n+1):
        ys, xs = np.nonzero(lab == i)
        if len(xs) < 150: continue
        c = np.array([xs.mean(), ys.mean()]); X = np.stack([xs, ys], 1) - c
        w, v = np.linalg.eigh(np.cov(X.T)); d = v[:, 1]; t = X @ d; s = X @ v[:, 0]
        L = t.max()-t.min(); T = s.max()-s.min()
        if L/max(T, 1) < 3 or T > 30 or L < 35: continue
        if any(abs(c[0]/g.shape[1]-fx) < .01 and abs(c[1]/g.shape[0]-fy) < .01 for fx, fy in fl.get('fakeSlots', [])): continue   # drawn on the blueprint but not a real wall
        slots.append(dict(c=c, d=d, t0=float(t.min()), t1=float(t.max()), L=float(L), T=float(T)))
    wall = ndi.binary_opening(g < 80, structure=np.ones((3, 3)))
    dtw = ndi.distance_transform_edt(~wall)
    _cache[key] = (slots, dtw, g.shape[1], g.shape[0])
    return _cache[key]

def _snap(slots, px, py, maxd):
    best = None
    for si, s in enumerate(slots):
        p = np.array([px, py]) - s['c']; n = max(1, round(s['L']/SEG)); seg = s['L']/n
        along = float(p @ s['d'])
        k = int(np.clip(np.floor((along-s['t0'])/seg), 0, n-1)); t = s['t0']+seg*(k+.5)
        tc = float(np.clip(along, s['t0'], s['t1'])); dist = float(np.hypot(*(s['c']+tc*s['d']-[px, py])))
        if best is None or dist < best[0]: best = (dist, s['c']+t*s['d'], s, k, si, seg)
    return best if best and best[0] <= maxd else None

_widx = {}
def _wallidx(cfg, floor):
    key = (cfg['name'], floor)
    if key not in _widx:
        fl = cfg['floors'][floor]
        g = np.array(Image.open(os.path.join(HERE, '..', '..', 'public', fl['image'].lstrip('/'))).convert('L')).astype(int)
        wall = ndi.binary_opening(g < 80, structure=np.ones((3, 3)))
        _widx[key] = ndi.distance_transform_edt(~wall, return_indices=True)
    return _widx[key]

def fit_gap(cfg, floor, px, py):
    """A barricade fills a doorway or window. Walls here run along the two axes, so for each axis look along lines near the object for an opening
    in the wall: clear between two solid wall ends 28-190 px apart (about 0.7-4.5 m). Returns (centre x, centre y, angle 0 or 90, length px) or None."""
    slots, dtw, W, H = _load(cfg, floor)
    wall = dtw == 0
    if not (0 <= int(px) < W and 0 <= int(py) < H): return None
    def solid(x, y, d, n, run=14):
        """is there a wall end at (x, y): wall under the line itself for `run` px further on, with the wall's thickness across it."""
        for t in range(0, run):
            xx = int(round(x + d[0]*t)); yy = int(round(y + d[1]*t))
            if not (0 <= xx < W and 0 <= yy < H) or not wall[yy, xx]: return False
        cnt = 0
        for o in range(-5, 6):
            xx = int(round(x + n[0]*o)); yy = int(round(y + n[1]*o))
            if 0 <= xx < W and 0 <= yy < H and wall[yy, xx]: cnt += 1
        return cnt >= 6
    best = None
    for ang, d in ((0, (1.0, 0.0)), (90, (0.0, 1.0))):
        n = (-d[1], d[0])
        for o in range(-80, 81, 2):
            x0 = px + n[0]*o; y0 = py + n[1]*o
            if not (0 <= int(x0) < W and 0 <= int(y0) < H) or wall[int(y0), int(x0)]: continue
            ends = []
            for sign in (1, -1):
                hit = None
                for t in range(1, 191):
                    xx = x0 + sign*d[0]*t; yy = y0 + sign*d[1]*t
                    if not (0 <= int(xx) < W and 0 <= int(yy) < H): break
                    if wall[int(round(yy)), int(round(xx))]: hit = t; break
                ends.append(hit)
            if None in ends or not (28 <= sum(ends) <= 190): continue
            e1 = (x0 + d[0]*ends[0], y0 + d[1]*ends[0]); e2 = (x0 - d[0]*ends[1], y0 - d[1]*ends[1])
            if not (solid(e1[0], e1[1], d, n) and solid(e2[0], e2[1], (-d[0], -d[1]), n)): continue
            # the opening must be clear along its whole length (no wall crossing the line)
            score = abs(o) + 0.2*abs(sum(ends) - 80)
            if best is None or score < best[0]:
                cx = x0 + d[0]*(ends[0]-ends[1])/2.0; cy = y0 + d[1]*(ends[0]-ends[1])/2.0
                best = (score, cx, cy, ang, float(sum(ends)))
    if best is None:
        # second pass: the object often sits on a wall end or just past the opening, so the start point may itself be wall.
        # Slide the start along each axis too, and take the opening closest to the object.
        for ang, d in ((0, (1.0, 0.0)), (90, (0.0, 1.0))):
            n = (-d[1], d[0])
            for o in range(-80, 81, 4):
                for sh in range(-120, 121, 6):
                    x0 = px + n[0]*o + d[0]*sh; y0 = py + n[1]*o + d[1]*sh
                    if not (0 <= int(x0) < W and 0 <= int(y0) < H) or wall[int(y0), int(x0)]: continue
                    ends = []
                    for sign in (1, -1):
                        hit = None
                        for t in range(1, 191):
                            xx = x0 + sign*d[0]*t; yy = y0 + sign*d[1]*t
                            if not (0 <= int(xx) < W and 0 <= int(yy) < H): break
                            if wall[int(round(yy)), int(round(xx))]: hit = t; break
                        ends.append(hit)
                    if None in ends or not (28 <= sum(ends) <= 190): continue
                    e1 = (x0 + d[0]*ends[0], y0 + d[1]*ends[0]); e2 = (x0 - d[0]*ends[1], y0 - d[1]*ends[1])
                    if not (solid(e1[0], e1[1], d, n) and solid(e2[0], e2[1], (-d[0], -d[1]), n)): continue
                    cx = x0 + d[0]*(ends[0]-ends[1])/2.0; cy = y0 + d[1]*(ends[0]-ends[1])/2.0
                    score = math.hypot(cx - px, cy - py) + 0.2*abs(sum(ends) - 80)
                    if best is None or score < best[0]: best = (score, cx, cy, ang, float(sum(ends)))
    if best is None: return None
    return best[1], best[2], best[3], best[4]

def fit_gap2(cfg, floor, px, py):
    """Fallback for barricades the strict search above cannot place: doorways in diagonal walls (45 and 135 degrees as well as the two axes) and
    openings whose wall ends are short blocks (the double-line walls draw only their end caps dark). Takes the opening closest to the object."""
    slots, dtw, W, H = _load(cfg, floor)
    wall = dtw == 0
    def at(x, y): return 0 <= int(round(x)) < W and 0 <= int(round(y)) < H and wall[int(round(y)), int(round(x))]
    def solid(x, y, d, n, run=4):        # loose on purpose: diagonal wall ends only touch the opening's line at their tip
        for t in range(0, run):
            if not at(x + d[0]*t, y + d[1]*t): return False
        return sum(1 for o in range(-5, 6) if at(x + n[0]*o, y + n[1]*o)) >= 3
    best = None
    r2 = math.sqrt(0.5)
    for ang, d in ((0, (1.0, 0.0)), (90, (0.0, 1.0)), (45, (r2, r2)), (135, (-r2, r2))):
        n = (-d[1], d[0])
        for o in range(-80, 81, 2):
            for sh in range(-120, 121, 3):
                x0 = px + n[0]*o + d[0]*sh; y0 = py + n[1]*o + d[1]*sh
                if not (0 <= int(x0) < W and 0 <= int(y0) < H) or wall[int(y0), int(x0)]: continue
                ends = []
                for sign in (1, -1):
                    hit = None
                    for t in range(1, 191):
                        if at(x0 + sign*d[0]*t, y0 + sign*d[1]*t): hit = t; break
                    ends.append(hit)
                if None in ends or not (28 <= sum(ends) <= 190): continue
                e1 = (x0 + d[0]*ends[0], y0 + d[1]*ends[0]); e2 = (x0 - d[0]*ends[1], y0 - d[1]*ends[1])
                if not (solid(e1[0], e1[1], d, n) and solid(e2[0], e2[1], (-d[0], -d[1]), n)): continue
                cx = x0 + d[0]*(ends[0]-ends[1])/2.0; cy = y0 + d[1]*(ends[0]-ends[1])/2.0
                score = math.hypot(cx - px, cy - py) + 1.0*abs(sum(ends) - 90)
                if best is None or score < best[0]: best = (score, cx, cy, ang, float(sum(ends)))
    return None if best is None else best[1:]

def fixed_fill(cfg, floor):
    slots, _, W, H = _load(cfg, floor); out = []
    for s in slots:
        n = max(1, round(s['L']/SEG)); seg = s['L']/n
        for k in range(n):
            q = s['c']+(s['t0']+seg*(k+.5))*s['d']
            out.append(dict(sx=round(q[0]/W, 4), sy=round(q[1]/H, 4), a=round(math.degrees(math.atan2(s['d'][1], s['d'][0])) % 180, 1), ln=round((seg-4)/W, 4), th=round(s['T']/W, 4)))
    return out

def apply(cfg, items):
    for it in items:
        if it.get('path'):      # drone flight: each point on the floor it was flown on
            pf = []
            for x, y, z in it['path']:
                f = 'top' if z >= cfg['floorSplitZ'] else 'ground'; fl = cfg['floors'].get(f)
                if not fl:
                    if it['k'] == 'p': pf.append(None)
                    continue
                _, _, W, H = _load(cfg, f); px = fl['sx']*x+fl['tx']; py = fl['ty']-fl['sy']*y-north_lift(f, y)
                if 0 <= px < W and 0 <= py < H: pf.append([round(px/W, 4), round(py/H, 4), f])
                elif it['k'] == 'p': pf.append([round(px/W, 4), round(py/H, 4), 'out'])     # off the blueprint (attackers still running in); one entry per second so the times stay aligned
            it['pf'] = pf
            if it['k'] == 'p': del it['path']; it['f'] = 'top'; continue
        fl = cfg['floors'].get(it['f'])
        if not fl: continue
        slots, dtw, W, H = _load(cfg, it['f'])
        px = fl['sx']*it['x']+fl['tx']; py = fl['ty']-fl['sy']*it['y']-north_lift(it['f'], it['y'])
        if not (0 <= px < W and 0 <= py < H): it['out'] = True; continue
        it['fx'] = round(px/W, 4); it['fy'] = round(py/H, 4)
        if it['k'] == 'x' and it.get('t') in ('hole', 'rotate'):
            # the debris lands up to ~1.5 m off the wall it came from: pull the marker onto the nearest wall (reinforceable slot first, then any wall line)
            sn = _snap(slots, px, py, 80)
            if not sn and it.get('t') in ('hole', 'rotate') and slots:
                it['out'] = True; continue      # nothing destructible nearby (hard walls only): that was loose debris, not a broken wall
            if sn: qx, qy = float(sn[1][0]), float(sn[1][1])
            else:
                _, idx = _wallidx(cfg, it['f'])
                wy, wx = idx[:, int(py), int(px)]
                qx, qy = (float(wx), float(wy)) if math.hypot(wx-px, wy-py) < 80 else (px, py)
            it['fx'] = round(qx/W, 4); it['fy'] = round(qy/H, 4)
            continue
        if it['k'] == 'h':
            gp = fit_gap(cfg, it['f'], px, py)
            if not gp or math.hypot(gp[0]-px, gp[1]-py) >= 110: gp = fit_gap2(cfg, it['f'], px, py)
            if gp and math.hypot(gp[0]-px, gp[1]-py) < 110:
                it['fx'] = round(gp[0]/W, 4); it['fy'] = round(gp[1]/H, 4); it['ba'] = round(gp[2], 1); it['bl'] = round((gp[3]-6)/W, 4)
            continue
        if it['k'] != 'r': continue
        sn = _snap(slots, px, py, 60)
        if not sn and dtw[int(py), int(px)] > 22: sn = _snap(slots, px, py, 170)
        if not sn: it['k'] = 'h'; continue
        dist, q, s, k, si, seg = sn
        it.update(sx=round(q[0]/W, 4), sy=round(q[1]/H, 4), a=round(math.degrees(math.atan2(s['d'][1], s['d'][0])) % 180, 1),
                  ln=round((seg-4)/W, 4), sl=round((s['L']-4)/W, 4), th=round(s['T']/W, 4), sid=si, seg=k, cx=round(float(s['c'][0])/W, 4), cy=round(float(s['c'][1])/H, 4))
    return [i for i in items if not i.get('out')]
