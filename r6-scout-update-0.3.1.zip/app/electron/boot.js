// First file Electron runs. Normally it just starts electron/main.js from the installed folder. If a newer program version was
// downloaded earlier (see updater.js) it starts that copy instead; if that copy fails to start, it is thrown away and the installed one runs.
const path = require('path');
const fs = require('fs');
const { app } = require('electron');

const bundled = path.join(__dirname, '..');
// libraries (express, sharp...) always come from the installed folder, so an update only has to carry program files
process.env.NODE_PATH = [path.join(bundled, 'node_modules'), process.env.NODE_PATH || ''].filter(Boolean).join(path.delimiter);
require('module').Module._initPaths();

const cmp = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 3; i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) - (y[i] || 0); } return 0; };
const updDir = path.join(app.getPath('userData'), 'updates');
const readJson = (f) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return null; } };
const drop = (f) => { try { fs.rmSync(f, { force: true, recursive: true }); } catch { /* ok */ } };

let main = path.join(__dirname, 'main.js');
const base = (readJson(path.join(bundled, 'package.json')) || {}).version || '0.0.0';
const cur = readJson(path.join(updDir, 'current.json'));
const pending = readJson(path.join(updDir, 'pending.json'));
if (cur && pending && pending.version === cur.version) {     // the last start of this update never finished: roll back
  drop(path.join(updDir, 'current.json')); drop(path.join(updDir, 'pending.json')); drop(path.join(updDir, cur.version));
} else if (cur) {
  const dir = path.join(updDir, cur.version, 'app');
  if (cmp(cur.version, base) > 0 && cmp(base, cur.minBase || '0.0.0') >= 0 && fs.existsSync(path.join(dir, 'electron', 'main.js'))) {
    global.R6_UPDATE = { version: cur.version, dir: path.join(updDir, cur.version) };
    fs.mkdirSync(updDir, { recursive: true });
    fs.writeFileSync(path.join(updDir, 'pending.json'), JSON.stringify({ version: cur.version }));
    main = path.join(dir, 'electron', 'main.js');
  } else if (cmp(cur.version, base) <= 0) { drop(path.join(updDir, 'current.json')); }   // the installed folder caught up
}
try { require(main); }
catch (e) {
  if (global.R6_UPDATE) { drop(path.join(updDir, 'current.json')); drop(path.join(updDir, 'pending.json')); global.R6_UPDATE = null; require(path.join(__dirname, 'main.js')); }
  else throw e;
}
