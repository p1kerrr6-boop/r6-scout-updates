// Checks the update page, downloads a newer program version (a small zip, not the whole installer) and arranges for boot.js to use it.
// Where updates come from is in update-config.json (a public GitHub repository). Only program files are replaced; your data is never touched.
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const crypto = require('crypto');

const cmp = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 3; i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) - (y[i] || 0); } return 0; };
const readJson = (f) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return null; } };
let busy = false;

function unzip(buf, outDir) {
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 65557); i--) if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  if (eocd < 0) throw new Error('not a zip file');
  const count = buf.readUInt16LE(eocd + 10); let p = buf.readUInt32LE(eocd + 16), total = 0;
  const root = path.resolve(outDir);
  for (let n = 0; n < count; n++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error('bad zip');
    const method = buf.readUInt16LE(p + 10), csize = buf.readUInt32LE(p + 20), nlen = buf.readUInt16LE(p + 28), xlen = buf.readUInt16LE(p + 30), clen = buf.readUInt16LE(p + 32), off = buf.readUInt32LE(p + 42);
    const name = buf.toString('utf8', p + 46, p + 46 + nlen); p += 46 + nlen + xlen + clen;
    if (name.endsWith('/')) continue;
    if (!/^(app|prep)\//.test(name) || name.includes('..') || path.isAbsolute(name)) throw new Error('unexpected file in update: ' + name);
    const dest = path.resolve(root, name); if (!dest.startsWith(root + path.sep)) throw new Error('bad path');
    const start = off + 30 + buf.readUInt16LE(off + 26) + buf.readUInt16LE(off + 28);
    const raw = buf.subarray(start, start + csize);
    const data = method === 0 ? raw : zlib.inflateRawSync(raw);
    total += data.length; if (total > 400 * 1024 * 1024) throw new Error('update too large');
    fs.mkdirSync(path.dirname(dest), { recursive: true }); fs.writeFileSync(dest, data);
  }
}

async function check({ app, dialog, win, version, userData, manual }) {
  if (busy) return; busy = true;
  const say = (message, detail) => dialog.showMessageBox(win() || undefined, { type: 'info', title: 'R6 Scout', message, detail: detail || '', buttons: ['OK'] });
  try {
    const cfg = readJson(path.join(__dirname, '..', 'update-config.json')) || readJson(path.join(process.resourcesPath || '', 'app', 'update-config.json'));
    if (!cfg || !cfg.owner || !cfg.repo) { if (manual) await say('Updates are not set up in this copy.'); return; }
    const base = process.env.R6_UPDATE_BASE || `https://raw.githubusercontent.com/${encodeURIComponent(cfg.owner)}/${encodeURIComponent(cfg.repo)}/${encodeURIComponent(cfg.branch || 'main')}/`;
    const res = await fetch(base + 'latest.json?t=' + Date.now(), { headers: { 'Cache-Control': 'no-cache' }, signal: AbortSignal.timeout(20000) });
    if (!res.ok) throw new Error('update page answered ' + res.status);
    const info = await res.json();
    if (!info || !/^\d+\.\d+\.\d+$/.test(info.version || '') || !/^[\w.-]+\.zip$/.test(info.zip || '') || !/^[0-9a-f]{64}$/.test(info.sha256 || '')) throw new Error('update page is not valid');
    if (cmp(info.version, version) <= 0) { if (manual) await say('You are up to date.', `R6 Scout ${version}`); return; }
    const installed = (readJson(path.join(__dirname, '..', 'package.json')) || {}).version;   // may be the downloaded copy; the installed base is what minBase refers to
    const baseVer = (readJson(path.join(process.resourcesPath || '', 'app', 'package.json')) || {}).version || installed || version;
    if (info.minBase && cmp(baseVer, info.minBase) < 0) {
      await say(`R6 Scout ${info.version} needs a full reinstall.`, 'This update changes parts that cannot be updated in place. Ask for the new installer and run it once; after that, updates are automatic again.');
      return;
    }
    const zres = await fetch(base + info.zip, { signal: AbortSignal.timeout(300000) });
    if (!zres.ok) throw new Error('download answered ' + zres.status);
    const buf = Buffer.from(await zres.arrayBuffer());
    if (crypto.createHash('sha256').update(buf).digest('hex') !== info.sha256) throw new Error('download did not match its checksum');
    const root = path.join(userData, 'updates'), tmp = path.join(root, info.version + '.tmp'), final = path.join(root, info.version);
    fs.rmSync(tmp, { recursive: true, force: true }); fs.mkdirSync(tmp, { recursive: true });
    unzip(buf, tmp);
    if (!fs.existsSync(path.join(tmp, 'app', 'electron', 'main.js'))) throw new Error('update has no program files');
    fs.rmSync(final, { recursive: true, force: true }); fs.renameSync(tmp, final);
    fs.writeFileSync(path.join(root, 'current.json'), JSON.stringify({ version: info.version, minBase: info.minBase || '0.0.0' }));
    for (const d of fs.readdirSync(root)) if (/^\d+\.\d+\.\d+(\.tmp)?$/.test(d) && d !== info.version) fs.rmSync(path.join(root, d), { recursive: true, force: true });
    const r = await dialog.showMessageBox(win() || undefined, { type: 'question', title: 'R6 Scout update', message: `R6 Scout ${info.version} is ready.`, detail: (info.notes ? info.notes + '\n\n' : '') + 'Restart now to use it? Your data is untouched.', buttons: ['Restart now', 'Later'], defaultId: 0, cancelId: 1 });
    if (r.response === 0) { app.relaunch(); app.exit(0); }
  } catch (e) {
    if (manual) await say('Could not check for updates.', String((e && e.message) || e));
  } finally { busy = false; }
}

module.exports = { check };
