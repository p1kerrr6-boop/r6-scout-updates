// Desktop shell: starts the R6 Scout server and the R6 Prep server on local ports and shows R6 Scout in a window
// (R6 Prep appears as its own tab inside it).
// Layout of the packaged folder:  R6 Scout.exe, resources/app (this project), resources/python, resources/bin (parser),
// resources/prep (R6 Prep server + built screens + its replay decoder).
const { app, BrowserWindow, Menu, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const net = require('net');
const { spawn } = require('child_process');

const APP_DIR = path.join(__dirname, '..');
const RES = process.resourcesPath;
const exe = process.platform === 'win32' ? '.exe' : '';
const BUNDLED_PREP = path.join(RES, 'prep');
// when an update is active, boot.js points the app at the downloaded copy (see updater.js); program files only, data stays where it was
const UPD = global.R6_UPDATE || null;
const PREP_DIR_NOW = () => (UPD && fs.existsSync(path.join(UPD.dir, 'prep', 'dist', 'index.mjs'))) ? path.join(UPD.dir, 'prep') : BUNDLED_PREP;
const VERSION = (() => { try { return JSON.parse(fs.readFileSync(path.join(APP_DIR, 'package.json'), 'utf8')).version; } catch { return '0.0.0'; } })();
// fixed ports where possible: the browser keeps logins and edits per address, so they must not change between launches
const PREF_SCOUT = 38410, PREF_PREP = 38411;

if (!app.requestSingleInstanceLock()) app.quit();

function isFree(port) {
  return new Promise((resolve) => { const s = net.createServer(); s.once('error', () => resolve(false)); s.listen(port, '127.0.0.1', () => s.close(() => resolve(true))); });
}
async function pickPort(pref) {
  if (await isFree(pref)) return pref;
  return new Promise((resolve, reject) => { const s = net.createServer(); s.once('error', reject); s.listen(0, '127.0.0.1', () => { const p = s.address().port; s.close(() => resolve(p)); }); });
}

const userData = () => app.getPath('userData');
const SETTINGS_FILE = () => path.join(userData(), 'prep-settings.json');
const KEYS = ['SUPABASE_URL', 'SUPABASE_ANON_KEY', 'SUPABASE_SERVICE_ROLE_KEY', 'ADMIN_EMAILS', 'DATABASE_URL', 'GOOGLE_OAUTH_CLIENT_ID', 'GOOGLE_OAUTH_CLIENT_SECRET'];
function readSettings() { try { return JSON.parse(fs.readFileSync(SETTINGS_FILE(), 'utf8')); } catch { return {}; } }
const isConfigured = (s) => Boolean(s.SUPABASE_URL && s.SUPABASE_ANON_KEY);

function setupEnv() {
  const py = path.join(RES, 'python', process.platform === 'win32' ? 'python.exe' : 'bin/python3');
  const dissect = path.join(RES, 'bin', 'r6-dissect' + exe);
  if (fs.existsSync(py)) process.env.PYTHON_BIN = py;
  if (fs.existsSync(dissect)) { process.env.R6_DISSECT_BIN = dissect; process.env.R6_DISSECT_TRK_BIN = dissect; }
  process.env.PYTHONIOENCODING = 'utf-8';
  process.env.HOST = '127.0.0.1';
  // the scout data lives in the user's profile, so updating the app never touches it
  const data = path.join(userData(), 'rounds.json');
  fs.mkdirSync(path.dirname(data), { recursive: true });
  const seed = [path.join(APP_DIR, 'data', 'rounds.json'), path.join(RES, 'app', 'data', 'rounds.json')].find((f) => fs.existsSync(f)) || '';
  if (!fs.existsSync(data) && seed) fs.copyFileSync(seed, data);
  process.env.DATA_FILE = data;
}

// ---- R6 Prep server (separate process so it can crash or restart without touching R6 Scout) ----
let prepProc = null, prepPort = 0;
function stopPrep() { if (prepProc) { try { prepProc.kill(); } catch { /* already gone */ } prepProc = null; } }
// an updated Prep folder has no node_modules of its own: link the installed one (a junction needs no admin rights on Windows)
function ensurePrepModules(dir) {
  if (dir === BUNDLED_PREP) return;
  const link = path.join(dir, 'node_modules');
  try { if (!fs.existsSync(link)) fs.symlinkSync(path.join(BUNDLED_PREP, 'node_modules'), link, 'junction'); } catch { /* Prep then cannot start; the next full installer fixes it */ }
}
function startPrep() {
  stopPrep();
  const PREP_DIR = PREP_DIR_NOW();
  const entry = path.join(PREP_DIR, 'dist', 'index.mjs');
  const st = readSettings();
  if (!fs.existsSync(entry) || !isConfigured(st)) return;
  ensurePrepModules(PREP_DIR);
  const env = { ...process.env, ELECTRON_RUN_AS_NODE: '1', NODE_ENV: 'production', PORT: String(prepPort), HOST: '127.0.0.1',
    STATIC_DIR: path.join(PREP_DIR, 'public'), LOCAL_DB_DIR: path.join(userData(), 'prep-db'), LOCAL_DB_SEED: path.join(BUNDLED_PREP, 'seed.sql'),
    REPLAY_DECODER_SCRIPT: path.join(PREP_DIR, 'decode.mjs') }; // reads match replays with the same r6-dissect R6 Scout uses
  delete env.DATABASE_URL;
  for (const k of KEYS) if (st[k]) env[k] = st[k];
  prepProc = spawn(process.execPath, ['--enable-source-maps', entry], { cwd: PREP_DIR, env, stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
  const log = fs.createWriteStream(path.join(userData(), 'prep.log'), { flags: 'a' });
  prepProc.stdout.pipe(log); prepProc.stderr.pipe(log);
  prepProc.on('exit', () => { prepProc = null; });
}

function addDesktopRoutes(expressApp) {
  const express = require('express');
  const sameOrigin = (req) => { const o = req.headers.origin; return !o || o === `http://127.0.0.1:${process.env.PORT}`; };
  expressApp.get('/desktop/prep', (_req, res) => res.json({ port: prepPort, configured: isConfigured(readSettings()), available: fs.existsSync(path.join(PREP_DIR_NOW(), 'dist', 'index.mjs')) }));
  expressApp.post('/desktop/prep-settings', express.json({ limit: '100kb' }), (req, res) => {
    if (!sameOrigin(req)) return res.status(403).json({ error: 'forbidden' });
    const cur = readSettings(), body = req.body || {};
    for (const k of KEYS) if (typeof body[k] === 'string' && body[k].trim()) cur[k] = body[k].trim();
    if (!isConfigured(cur)) return res.status(400).json({ error: 'Supabase URL and anon key are required.' });
    fs.writeFileSync(SETTINGS_FILE(), JSON.stringify(cur, null, 2), { mode: 0o600 });
    startPrep();
    res.json({ port: prepPort, configured: true, available: true });
  });
}

// ---- input/output folders for the batch pipeline: chosen with the native folder dialog, read/written by this process ----
const FOLDERS_FILE = () => path.join(userData(), 'pipeline-folders.json');
// default folders: Documents\R6 Scout\Input (drop your .rec files here) and \Output (results appear here)
const defaultFolders = () => { const base = path.join(app.getPath('documents'), 'R6 Scout'); return { in: path.join(base, 'Input'), out: path.join(base, 'Output') }; };
function readFolders() {
  const d = defaultFolders(); let j = {};
  try { j = JSON.parse(fs.readFileSync(FOLDERS_FILE(), 'utf8')); } catch { /* first run */ }
  const pick = (saved, dflt) => { if (saved && fs.existsSync(saved)) return saved; try { fs.mkdirSync(dflt, { recursive: true }); } catch { /* read-only */ } return dflt; };
  return { in: pick(j.in, d.in), out: pick(j.out, d.out) };
}
function addFolderRoutes(expressApp) {
  const express = require('express');
  // custom header = browsers refuse to send it from other websites without our permission, so only this window can use these routes
  const guard = (req, res, next) => (req.headers['x-r6-desktop'] === '1' && (!req.headers.origin || req.headers.origin === `http://127.0.0.1:${process.env.PORT}`)) ? next() : res.status(403).json({ error: 'forbidden' });
  const resolveIn = (kind, rel) => {
    const root = readFolders()[kind]; if (!root) return null;
    const full = path.resolve(root, '.' + path.sep + String(rel || '').replace(/\\/g, '/'));
    return (full === path.resolve(root) || full.startsWith(path.resolve(root) + path.sep)) ? full : null;
  };
  expressApp.post('/desktop/open', guard, express.json(), (req, res) => { const f = readFolders()[req.body && req.body.kind === 'out' ? 'out' : 'in']; shell.openPath(f); res.json({ path: f }); });
  expressApp.get('/desktop/folders', guard, (_req, res) => res.json(readFolders()));
  expressApp.post('/desktop/pick', guard, express.json(), async (req, res) => {
    const kind = req.body && req.body.kind === 'out' ? 'out' : 'in';
    const r = await dialog.showOpenDialog(win, { title: kind === 'in' ? 'Choose the folder with your .rec replays' : 'Choose the folder for the results', properties: ['openDirectory', 'createDirectory'], defaultPath: readFolders()[kind] || undefined });
    if (r.canceled || !r.filePaths[0]) return res.json({ path: '' });
    const cur = readFolders(); cur[kind] = r.filePaths[0];
    fs.writeFileSync(FOLDERS_FILE(), JSON.stringify(cur));
    res.json({ path: cur[kind] });
  });
  expressApp.get('/desktop/fs/list', guard, (req, res) => {
    const d = resolveIn(req.query.root === 'out' ? 'out' : 'in', req.query.p); if (!d) return res.status(404).json({ error: 'no such folder' });
    try { res.json(fs.readdirSync(d, { withFileTypes: true }).map((e) => ({ name: e.name, kind: e.isDirectory() ? 'directory' : 'file' }))); } catch { res.status(404).json({ error: 'no such folder' }); }
  });
  expressApp.get('/desktop/fs/file', guard, (req, res) => {
    const f = resolveIn(req.query.root === 'out' ? 'out' : 'in', req.query.p);
    if (!f || !fs.existsSync(f) || !fs.statSync(f).isFile()) return res.status(404).json({ error: 'no such file' });
    fs.createReadStream(f).pipe(res);
  });
  expressApp.put('/desktop/fs/file', guard, express.raw({ type: () => true, limit: '300mb' }), (req, res) => {
    const f = resolveIn('out', req.query.p); if (!f || f === path.resolve(readFolders().out)) return res.status(400).json({ error: 'bad path' });
    try { fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, req.body); res.json({ ok: true }); } catch (e) { res.status(500).json({ error: String(e.message) }); }
  });
}

let win = null, server = null;
async function start() {
  setupEnv();
  readFolders(); // creates Documents\\R6 Scout\\Input and \\Output on first launch
  const port = await pickPort(PREF_SCOUT);
  process.env.PORT = String(port);
  prepPort = await pickPort(PREF_PREP === port ? PREF_PREP + 1 : PREF_PREP);
  process.env.FRAME_SRC = `http://127.0.0.1:${prepPort}`; // lets the Prep tab show inside the window
  const expressApp = require(path.join(APP_DIR, 'server.js'));
  addDesktopRoutes(expressApp);
  addFolderRoutes(expressApp);
  server = expressApp.listen(port, '127.0.0.1');
  await new Promise((res, rej) => { server.once('listening', res); server.once('error', rej); });
  startPrep();
  win = new BrowserWindow({ width: 1500, height: 960, minWidth: 900, minHeight: 600, title: 'R6 Scout', backgroundColor: '#0f1115', autoHideMenuBar: true, icon: path.join(APP_DIR, 'electron', 'icon.png'), webPreferences: { contextIsolation: true } });
  win.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: 'deny' }; });
  await win.loadURL(`http://127.0.0.1:${port}/`);
  try { fs.rmSync(path.join(userData(), 'updates', 'pending.json'), { force: true }); } catch { /* ok */ }   // this version started fine
  setTimeout(() => updater.check({ app, dialog, win: () => win, version: VERSION, userData: userData(), manual: false }), 6000);
  win.on('closed', () => { win = null; });
}

const updater = require('./updater');
Menu.setApplicationMenu(Menu.buildFromTemplate([
  { label: 'View', submenu: [{ role: 'reload' }, { role: 'forceReload' }, { role: 'toggleDevTools' }, { type: 'separator' }, { role: 'resetZoom' }, { role: 'zoomIn' }, { role: 'zoomOut' }, { role: 'togglefullscreen' }] },
  { label: 'Help', submenu: [{ label: `R6 Scout ${VERSION}`, enabled: false }, { label: 'Check for updates', click: () => updater.check({ app, dialog, win: () => win, version: VERSION, userData: userData(), manual: true }) }] },
  { label: 'Data', submenu: [{ label: 'Open input folder (put .rec files here)', click: () => shell.openPath(readFolders().in) }, { label: 'Open output folder', click: () => shell.openPath(readFolders().out) }, { type: 'separator' }, { label: 'Open data folder', click: () => shell.openPath(userData()) }] },
]));

app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
app.whenReady().then(() => start().catch((e) => { dialog.showErrorBox('R6 Scout could not start', String((e && e.stack) || e)); app.quit(); }));
app.on('before-quit', stopPrep);
app.on('window-all-closed', () => { stopPrep(); if (server) server.close(); app.quit(); });
