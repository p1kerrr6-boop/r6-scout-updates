# Drop your map PNG files here (e.g. bank.png, chalet.png, border.png...)
