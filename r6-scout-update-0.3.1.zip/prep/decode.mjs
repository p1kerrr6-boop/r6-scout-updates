// Replay decoder for the desktop app: same contract as the Go helper (replay-decoder <archive.zip> prints
// [{file, header:{site, gameVersion, teams, map}} | {file, error}]), but it uses the r6-dissect program R6 Scout already ships.
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import zlib from "node:zlib";
import { execFileSync } from "node:child_process";

const archive = process.argv[2];
const bin = process.env.R6_DISSECT_BIN;
if (!archive || !bin) { console.error("Expected an archive path and R6_DISSECT_BIN"); process.exit(2); }

const buf = fs.readFileSync(archive);
// zip central directory (no zip64: archives are capped at 512 MB)
let eocd = -1;
for (let i = buf.length - 22; i >= Math.max(0, buf.length - 65557); i--) if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
if (eocd < 0) { console.error("Not a zip archive"); process.exit(1); }
const count = buf.readUInt16LE(eocd + 10);
let p = buf.readUInt32LE(eocd + 16);
const entries = [];
for (let n = 0; n < count; n++) {
  if (buf.readUInt32LE(p) !== 0x02014b50) break;
  const method = buf.readUInt16LE(p + 10), csize = buf.readUInt32LE(p + 20), nlen = buf.readUInt16LE(p + 28),
    xlen = buf.readUInt16LE(p + 30), clen = buf.readUInt16LE(p + 32), off = buf.readUInt32LE(p + 42);
  const name = buf.toString("utf8", p + 46, p + 46 + nlen);
  entries.push({ name, method, csize, off });
  p += 46 + nlen + xlen + clen;
}

const mapName = (m) => {
  const n = m && typeof m === "object" ? m.name : m;
  return typeof n === "string" ? { id: m && m.id, name: n.replace(/Y\d+$/, "") } : m;
};
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "r6prep-dec-"));
const out = [];
try {
  for (const e of entries) {
    if (!/\.rec$/i.test(e.name) || e.name.includes("..")) continue;
    const row = { file: e.name };
    try {
      const lh = e.off, nlen = buf.readUInt16LE(lh + 26), xlen = buf.readUInt16LE(lh + 28), start = lh + 30 + nlen + xlen;
      const raw = buf.subarray(start, start + e.csize);
      const data = e.method === 0 ? raw : zlib.inflateRawSync(raw);
      const rec = path.join(tmp, "r.rec"), js = path.join(tmp, "r.json");
      fs.writeFileSync(rec, data); fs.rmSync(js, { force: true });
      try { execFileSync(bin, [rec, "-o", js], { timeout: 120000, stdio: "pipe", maxBuffer: 1 << 20 }); } catch (err) { if (process.env.DEC_DEBUG) console.error(String(err.stderr).slice(0, 300)); }
      if (!fs.existsSync(js)) { row.error = "Round could not be decoded completely"; }
      else {
        const j = JSON.parse(fs.readFileSync(js, "utf8")); const h = j.header || (j.gameVersion ? j : null);
        if (!h) row.error = "Round could not be decoded completely";
        else row.header = { site: h.site, gameVersion: h.gameVersion, teams: h.teams, map: mapName(h.map) };
      }
    } catch (err) { if (process.env.DEC_DEBUG) console.error(String(err)); row.error = "Decoder could not read this game version"; }
    out.push(row);
  }
} finally { fs.rmSync(tmp, { recursive: true, force: true }); }
process.stdout.write(JSON.stringify(out));
