// Updates must be signed. The publisher signs "version, minBase, zip name and checksum" with a private key that never leaves their computer;
// this app only holds the matching public key (update-key.json), so nobody who gets into the update page can make it install their code.
const crypto = require('crypto');

const message = (info) => Buffer.from(['r6-scout-update', `version=${info.version}`, `minBase=${info.minBase || ''}`, `zip=${info.zip}`, `sha256=${info.sha256}`].join('\n'), 'utf8');

function verify(info, publicKeyPem) {
  try {
    if (!info || typeof info.signature !== 'string' || !/^[A-Za-z0-9+/]+={0,2}$/.test(info.signature)) return false;
    return crypto.verify(null, message(info), crypto.createPublicKey(publicKeyPem), Buffer.from(info.signature, 'base64'));
  } catch { return false; }
}
const sign = (info, privateKeyPem) => crypto.sign(null, message(info), crypto.createPrivateKey(privateKeyPem)).toString('base64');

module.exports = { message, verify, sign };
